import * as i0 from '@angular/core';
import { Injectable, Component, Input, EventEmitter, Output, Directive, NgModule } from '@angular/core';
import { EVENT_DATA_LOAD_END, EVENT_NODE_ADDED, EVENT_GROUP_ADDED, BrowserUIBase, log, MiniviewPlugin, ShapeLibraryImpl, SvgExporter, SvgExporterUI, ImageExporter, ImageExporterUI, getsert, extend, OVERLAY_TYPE_CUSTOM, render, EVENT_NODE_UPDATED, EVENT_PORT_ADDED, EVENT_GROUP_UPDATED, EVENT_PORT_UPDATED, EVENT_EDGE_UPDATED, EVENT_EDGE_ADDED, DEFAULT, DropManager, SurfaceDropManager, ShapeLibraryDefaults, ShapeLibraryPalette, SurfaceMode, EVENT_SURFACE_MODE_CHANGED, EVENT_UNDOREDO_UPDATE, TRUE, FALSE, EdgeTypePicker } from '@jsplumbtoolkit/browser-ui';

/**
 * The default ID of a shape library stored/retrieved on the surface. If your app only uses one shape library you wont need to
 * provide a shapeLibraryId to your shape palette or shape components.
 */
const DEFAULT_SHAPE_LIBRARY_ID = "shapeLibrary";

const toolkits = {};
const surfaces = {};
const miniviews = {};
const _workQueues = {};
const _surfaceEventHandlers = {};
function _addASurfaceListener(surfaceId, event, fn) {
    _surfaceEventHandlers[surfaceId] = _surfaceEventHandlers[surfaceId] || {};
    _surfaceEventHandlers[surfaceId][event] = fn;
    surfaces[surfaceId].toolkitInstance.bind(event, fn);
}
function _addSurfaceListeners(surfaceId) {
    const dle = function () {
        setTimeout(miniviews[surfaceId].invalidate, 0);
    }.bind(this);
    const na = function (params) {
        setTimeout(function () {
            miniviews[surfaceId].invalidate(params.node.id);
        }, 0);
    }.bind(this);
    const ga = function (params) {
        setTimeout(function () {
            miniviews[surfaceId].invalidate(params.group.id);
        }, 0);
    }.bind(this);
    _addASurfaceListener(surfaceId, EVENT_DATA_LOAD_END, dle);
    _addASurfaceListener(surfaceId, EVENT_NODE_ADDED, na);
    _addASurfaceListener(surfaceId, EVENT_GROUP_ADDED, ga);
}
/**
 * Angular specific renderer.
 * @public
 */
class BrowserUIAngular extends BrowserUIBase {
    render(container, options) {
        log("render called directly on BrowserUIAngular class: should not happen. Surface component should use internal render.");
        return null;
    }
}
/**
 * The jsPlumbService provides the core of the Angular integration, offering methods to create and retrieve instances of the Toolkit.
 * @public
 */
class jsPlumbService {
    constructor() {
        /**
         * datastore for user set values.
         */
        this.data = new Map();
    }
    /**
     * Create (or get if existing) a Toolkit instance.
     * @param id ID of the instance to either create or retrieve.
     * @param params Optional constructor options for the Toolkit instance.
     * @public
     */
    getToolkit(id, params) {
        if (id == null) {
            throw new Error("Cannot retrieve or create Toolkit with undefined id");
        }
        if (!toolkits[id]) {
            toolkits[id] = new BrowserUIAngular(params || {});
        }
        return toolkits[id];
    }
    /**
     * Registers a surface. This method is for internal use.
     * @param id
     * @param surface
     * @internal
     */
    addSurface(id, surface) {
        surfaces[id] = surface;
        _surfaceEventHandlers[id] = {};
        surface._ngId = id;
        if (_workQueues[id]) {
            for (let i = 0; i < _workQueues[id].length; i++) {
                try {
                    _workQueues[id][i][0](surface, _workQueues[id][i][1]);
                }
                catch (e) {
                    log("Cannot create component " + e);
                }
            }
        }
        delete _workQueues[id];
    }
    /**
     * Removes the given surface. For internal use.
     * @param id
     * @param surface
     * @internal
     */
    removeSurface(id, surface) {
        for (let event in _surfaceEventHandlers[id]) {
            surface.toolkitInstance.unbind(event, _surfaceEventHandlers[id][event]);
        }
        surface.destroy();
        delete surfaces[id];
        delete miniviews[id];
    }
    /**
     * Gets the surface with the given id, passing it to the supplied callback function. If a surface with the given ID does
     * not exist, the request is queued, and then if a surface with the given ID is subsequently registered, each callback
     * for that surface registered via this method is executed in turn.
     * @param id ID of the surface to retrieve
     * @param callback Function to call when the surface has been retrieved.
     * @param _params Optional parameters to pass back into the callback upon successful retrieval of the surface.
     * @public
     */
    getSurface(id, callback, _params) {
        const surface = surfaces[id];
        if (surface) {
            callback(surface);
        }
        else {
            _workQueues[id] = _workQueues[id] || [];
            _workQueues[id].push([callback, _params || {}]);
        }
    }
    /**
     * Adds a miniview to the surface with the given id. For internal use.
     * @param surfaceId
     * @param params
     * @internal
     */
    addMiniview(surfaceId, params) {
        this.getSurface(surfaceId, (surface) => {
            let miniview = surface.addPlugin({
                type: MiniviewPlugin.type,
                options: {
                    container: params.container,
                    elementFilter: params.elementFilter,
                    typeFunction: params.typeFunction
                }
            });
            miniviews[surfaceId] = miniview;
            _addSurfaceListeners(surfaceId);
        }, null);
    }
    /**
     * Store an arbitrary value on the service.
     * @param key
     * @param value
     * @public
     */
    store(key, value) {
        this.data.set(key, value);
    }
    /**
     * Retrieve an arbitrary value from the service.
     * @param key
     * @public
     */
    retrieve(key) {
        return this.data.get(key);
    }
    /**
     * Register a shape library. A convenience method that creates a shape library and stores it
     * @param shapeSets the Shapes sets to register
     * @param key Key to register the shape library with. If you omit this, the default id will be used. If you call this
     * method multiple times without providing a `key`, the service will just overwrite what you previously stored.
     * @public
     */
    registerShapeLibrary(shapeSets, key) {
        this.store(key || DEFAULT_SHAPE_LIBRARY_ID, new ShapeLibraryImpl(shapeSets));
    }
    /**
     * Retrieve a shape library. A convenience method that prefixes the given key and then calls `retrieve`.
     * @param key Key used to register the shape library. If omitted, the default shape library key will be used.
     * @public
     */
    retrieveShapeLibrary(key) {
        return this.retrieve(key || DEFAULT_SHAPE_LIBRARY_ID);
    }
    /**
     * Export an SVG from some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    exportSvg(options) {
        const shapeLibraryId = options.shapeLibraryId;
        const shapeLibrary = options.shapeLibrary || this.retrieveShapeLibrary(shapeLibraryId) || options.surface._$_shapeLibrary;
        if (shapeLibrary == null) {
            log("Cannot export SVG - no shape library found");
            return {
                width: 0, height: 0, svg: "", dataUrl: "", viewBoxOnlySvg: ""
            };
        }
        else {
            return new SvgExporter(options.surface, shapeLibrary).export(options);
        }
    }
    /**
     * Show the export SVG UI for some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    showSvgExportUI(options) {
        const shapeLibraryId = options.shapeLibraryId;
        const shapeLibrary = options.shapeLibrary || this.retrieveShapeLibrary(shapeLibraryId) || options.surface._$_shapeLibrary;
        if (shapeLibrary == null) {
            log("Cannot init export SVG UI - no shape library found");
            return {
                width: 0, height: 0, svg: "", dataUrl: "", viewBoxOnlySvg: ""
            };
        }
        else {
            return new SvgExporterUI(options.surface, shapeLibrary).export(options);
        }
    }
    /**
     * Export an image from some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    exportImage(options, onready) {
        const shapeLibraryId = options.shapeLibraryId;
        const shapeLibrary = options.shapeLibrary || this.retrieveShapeLibrary(shapeLibraryId) || options.surface._$_shapeLibrary;
        if (shapeLibrary == null) {
            log("Cannot export image - no shape library found");
        }
        else {
            new ImageExporter(options.surface, shapeLibrary).export(options, onready);
        }
    }
    /**
     * Show the image export UI for some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    showImageExportUI(options) {
        const shapeLibraryId = options.shapeLibraryId;
        const shapeLibrary = options.shapeLibrary || this.retrieveShapeLibrary(shapeLibraryId) || options.surface._$_shapeLibrary;
        if (shapeLibrary == null) {
            log("Cannot init export image UI - no shape library found");
        }
        else {
            new ImageExporterUI(options.surface, shapeLibrary).export(options);
        }
    }
    exportPNG(options, onready) {
        options.type = "image/png";
        this.exportImage(options, onready);
    }
    exportJPG(options, onready) {
        options.type = "image/jpeg";
        options.quality = options.quality || 1.0;
        this.exportImage(options, onready);
    }
}
jsPlumbService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
jsPlumbService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbService, decorators: [{
            type: Injectable
        }] });

/**
 * A component that provides a miniview.
 * @public
 */
class jsPlumbMiniviewComponent {
    constructor(el, $jsplumb) {
        this.el = el;
        this.$jsplumb = $jsplumb;
    }
    /**
     * @internal
     */
    ngAfterViewInit() {
        if (!this.surfaceId) {
            throw new Error("surface-id attribute not specified on jsplumb-miniview component");
        }
        this.$jsplumb.addMiniview(this.surfaceId, {
            container: this.el.nativeElement.childNodes[0],
            elementFilter: this.elementFilter,
            typeFunction: this.typeFunction,
            activeTracking: this.activeTracking !== false,
            clickToCenter: this.clickToCenter !== false
        });
    }
    /**
     * @internal
     */
    redraw() {
        this.$jsplumb.getSurface(this.surfaceId, (s) => {
            const m = s.getPlugin(MiniviewPlugin.type);
            if (m != null) {
                m.invalidate();
            }
        });
    }
}
jsPlumbMiniviewComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbMiniviewComponent, deps: [{ token: i0.ElementRef }, { token: jsPlumbService }], target: i0.ɵɵFactoryTarget.Component });
jsPlumbMiniviewComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.4.0", type: jsPlumbMiniviewComponent, selector: "jsplumb-miniview", inputs: { surfaceId: "surfaceId", elementFilter: "elementFilter", typeFunction: "typeFunction", activeTracking: "activeTracking", clickToCenter: "clickToCenter" }, ngImport: i0, template: `<div></div>`, isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbMiniviewComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'jsplumb-miniview',
                    template: `<div></div>`
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: jsPlumbService }]; }, propDecorators: { surfaceId: [{
                type: Input
            }], elementFilter: [{
                type: Input
            }], typeFunction: [{
                type: Input
            }], activeTracking: [{
                type: Input
            }], clickToCenter: [{
                type: Input
            }] } });

/**
 * Defines the type for an overlay that is represented by an angular component. Use this value in your views instead of
 * "Arrow", "Label" etc.
 * @public
 */
const AngularComponentOverlayType = "AngularComponent";
/**
 * A base implementation of AngularOverlayComponent that you can use if its convenient for you. This class offers
 * an `updateEdge` and a `removeEdge` method, as helpers.
 * @public
 */
class BaseAngularOverlayComponent {
    updateEdge(updates) {
        this.toolkit.updateEdge(this.edge, updates);
    }
    removeEdge() {
        this.toolkit.removeEdge(this.edge);
    }
}

/**
 * Provides a component that manages a surface.
 */
class jsPlumbSurfaceComponent {
    constructor(el, $jsplumb, componentFactoryResolver, viewContainerRef) {
        this.el = el;
        this.$jsplumb = $jsplumb;
        this.componentFactoryResolver = componentFactoryResolver;
        this.viewContainerRef = viewContainerRef;
        /**
         * output event emitter, for proxying events from vertex components.
         */
        this.vertexEvent = new EventEmitter();
        /**
         * map of overlays keyed by Connection id (NOT edge id). these are overlays that were added to connections as they were being
         * dragged, and so they didnt have an associated edge.
         * @internal
         */
        this._uninitialisedOverlays = new Map();
    }
    /**
     * @internal
     * @param connectionId
     * @param component
     * @param el
     */
    _addUninitializedOverlay(connectionId, componentRef, createdComponent) {
        const overlays = getsert(this._uninitialisedOverlays, connectionId, () => []);
        overlays.push({ componentRef, createdComponent });
    }
    /**
     * abstract out the difference in accessing nativeElement between angular 2 (first case) and angular 4/5 (second case)
     * @param component
     * @internal
     */
    getNativeElement(component) {
        return component.location.nativeElement.childNodes[0]; //(component._nativeElement || component.location.nativeElement).childNodes[0];
    }
    /**
     * on node/group update, store the new data in the view
     * @internal
     */
    nodeOrGroupUpdated(params) {
        let info = this.surface.getObjectInfo(params.vertex);
        if (info.el && info.el._jsPlumbNgComponent) {
            const component = info.el._jsPlumbNgComponent;
            component.obj = params.vertex.data;
            if (component.changeDetectorRef) {
                component.changeDetectorRef.detectChanges();
            }
        }
    }
    portUpdated(params) {
        let info = this.surface.getObjectInfo(params.port);
        if (info.el) {
            const component = info.el._jsPlumbNgComponent || info.el.parentNode._jsPlumbNgComponent;
            if (component) {
                component.obj = params.port.data;
                if (component.changeDetectorRef) {
                    component.changeDetectorRef.detectChanges();
                }
            }
        }
    }
    /**
     * When an edge updated event is received, check for angular overlays, and if they have a change detector,
     * invoke it. Used with OnPush change detection.
     * @internal
     * @param params
     */
    edgeUpdated(params) {
        const connection = this.surface.getRenderedConnection(params.edge.id);
        if (connection) {
            for (let id in connection.overlays) {
                const canvas = connection.overlays[id].canvas;
                if (canvas && canvas._jsPlumbNgComponent && canvas._jsPlumbNgComponent.changeDetectorRef) {
                    canvas._jsPlumbNgComponent.changeDetectorRef.detectChanges();
                }
            }
        }
    }
    /**
     * This method is invoked when a connection is established in the UI (not in the model), meaning it has just been
     * dragged. If there were any angular overlays on the edge they will not have been initialised properly, due to there
     * not being an edge prior to the finalisation of the connection. This method sets the `edge` and `obj` values on
     * the overlay, and then invokes its change detector, if set.
     * @param p
     * @internal
     */
    _edgeAdded(p) {
        if (p.connection && p.addedByMouse) {
            const overlays = this._uninitialisedOverlays.get(p.connection.id);
            if (overlays) {
                overlays.forEach((c) => {
                    c.componentRef.obj = p.connection.edge.data;
                    c.componentRef.edge = p.connection.edge;
                    if (c.createdComponent.changeDetectorRef) {
                        setTimeout(() => {
                            c.createdComponent.changeDetectorRef.detectChanges();
                        }, 0);
                    }
                });
                this._uninitialisedOverlays.delete(p.connection.id);
            }
        }
    }
    /**
    * @internal
    */
    ngOnInit() {
        if (!this.toolkitId) {
            throw new Error("toolkitId attribute not specified on jsplumb-surface component");
        }
    }
    /**
     *
     * @param view
     * @internal
     */
    _processAngularOverlays(view) {
        const self = this;
        const edgeTypes = view.edges || {};
        for (let edgeTypeId in edgeTypes) {
            const edgeType = edgeTypes[edgeTypeId];
            if (edgeType.overlays != null) {
                edgeType.overlays = edgeType.overlays.map((o) => {
                    if (typeof o === "string") {
                        return o;
                    }
                    else {
                        const fo = o;
                        if (fo.type === AngularComponentOverlayType) {
                            const newSpec = extend(fo, {
                                type: OVERLAY_TYPE_CUSTOM
                            });
                            newSpec.options = newSpec.options || {};
                            newSpec.options.create = (c) => {
                                const el = document.createElement("div");
                                const componentFactory = self.componentFactoryResolver.resolveComponentFactory(newSpec.options.component);
                                let createdComponent = self.viewContainerRef.createComponent(componentFactory);
                                // `_component` is for all versions from 2 -> 9. `instance` is when using 8+ and the Ivy compiler.
                                let angularOverlayComponent = (createdComponent._component || createdComponent.instance);
                                let nativeEl = createdComponent.location.nativeElement.childNodes[0];
                                el.appendChild(nativeEl);
                                el._jsPlumbNgComponent = angularOverlayComponent;
                                /*
                                  There was an issue with these angular overlays on edges that are being dragged: there is no edge
                                  when they are created, and so an error is thrown by the code that tries to get the edge's `obj`.
                                  this code here fixes that null pointer exception, and as long as a dragging edge is discarded and recreated
                                  this code should be fine. It does mean that the overlay wont necessarily paint correctly while dragging,
                                  but maybe we don't want this overlay while dragging anyway? Maybe there is room for some concept of
                                  overlays that are only visible when an edge has been finalised?
              
                                 */
                                const edgeId = c.parameters.edgeId;
                                if (edgeId != null) {
                                    const edge = self.toolkit.getEdge(edgeId);
                                    angularOverlayComponent.edge = edge;
                                    angularOverlayComponent.obj = edge.data;
                                }
                                else {
                                    angularOverlayComponent.obj = {};
                                    this._addUninitializedOverlay(c.id, angularOverlayComponent, createdComponent);
                                }
                                angularOverlayComponent.toolkit = self.toolkit;
                                angularOverlayComponent.surface = self.surface;
                                createdComponent.changeDetectorRef.detectChanges();
                                return el;
                            };
                            return newSpec;
                        }
                        else {
                            return fo;
                        }
                    }
                });
            }
        }
        return view;
    }
    /**
     * @internal
     */
    ngAfterViewInit() {
        const view = this._processAngularOverlays(this.view || {});
        const self = this;
        const templateRenderer = {
            asynchronous: false,
            reactive: true,
            update: (el, data, v, renderer) => { },
            render: (directiveId, data, toolkit, objectType, surface, def, modelObject, node, eventInfo) => {
                let component;
                if (def.component == null) {
                    log("No `component` provided for vertex of type [" + directiveId + "] : cannot render this component");
                }
                else {
                    component = def.component;
                }
                const componentFactory = self.componentFactoryResolver.resolveComponentFactory(component);
                let createdComponent = self.viewContainerRef.createComponent(componentFactory);
                // `_component` is for all versions from 2 -> 9. `instance` is when using 8+ and the Ivy compiler.
                let _componentRef = createdComponent._component || createdComponent.instance;
                _componentRef.obj = data || {};
                _componentRef.toolkit = toolkit;
                _componentRef.surface = surface;
                _componentRef.modelObject = modelObject;
                // populate any declared inputs from obj
                componentFactory.inputs.forEach((pt) => {
                    const pv = _componentRef.obj[pt.propName];
                    if (pv != null) {
                        _componentRef[pt.propName] = pv;
                    }
                });
                componentFactory.outputs.forEach((pt) => {
                    _componentRef[pt.propName].subscribe(data => self.vertexEvent.emit({ vertex: modelObject, event: pt.propName, payload: data, component: createdComponent }));
                });
                createdComponent.changeDetectorRef.detectChanges();
                // TODO this should not be necessary
                const nativeElement = self.getNativeElement(createdComponent);
                _componentRef._el = nativeElement;
                _componentRef._el._jsPlumbNgComponent = _componentRef;
                _componentRef._el._ref = createdComponent; // we store _ref so we can call `destroy` on it later if the node is removed.
                surface.vertexRendered(modelObject, nativeElement, def, eventInfo);
            },
            cleanupVertex: (objId, el) => {
                el._ref && el._ref.destroy();
                el.parentNode && el.parentNode.removeChild(el);
            },
            cleanupPort: (objId, el) => {
                el._ref && el._ref.destroy();
                el.parentNode && el.parentNode.removeChild(el);
            }
        };
        const renderParams = extend(this.renderParams || {}, {
            view: view
        });
        let toolkit = this.$jsplumb.getToolkit(this.toolkitId, this.toolkitParams);
        this.toolkit = toolkit;
        this.surface = render(toolkit, self.el.nativeElement.childNodes[0], templateRenderer, renderParams);
        this.$jsplumb.addSurface(this.surfaceId, this.surface);
        // ----------------
        //
        // i think probably this could just go in the Surface really. it's IE11+, and that's fine as a minimum for jtk 5.
        // but do we need it in the vanilla jtk?  maybe in the community edition, to get around having to call `revalidate`
        // const observer = new MutationObserver((mutations) => {
        //     mutations.forEach((mutation) => console.log("MUTATION :", mutation));
        // });
        //
        // observer.observe(this.surface.getContainer(), {
        //     attributes: true,
        //     attributeFilter:['data-jtk-port', 'data-jtk-port-id', 'data-jtk-source', 'data-jtk-target'],
        //     subtree:true
        //     // childList: true,
        //     // characterData: true
        // });
        // ----------------
        this.nodeUpdateFn = this.nodeOrGroupUpdated.bind(this);
        toolkit.bind(EVENT_NODE_UPDATED, this.nodeUpdateFn);
        toolkit.bind(EVENT_PORT_ADDED, this.nodeUpdateFn);
        toolkit.bind(EVENT_GROUP_UPDATED, this.nodeUpdateFn);
        this.portUpdateFn = this.portUpdated.bind(this);
        toolkit.bind(EVENT_PORT_UPDATED, this.portUpdateFn);
        this.edgeUpdateFn = this.edgeUpdated.bind(this);
        toolkit.bind(EVENT_EDGE_UPDATED, this.edgeUpdateFn);
        this.edgeAddFn = this._edgeAdded.bind(this);
        this.surface.bind(EVENT_EDGE_ADDED, this.edgeAddFn);
    }
    /**
     * @internal
     */
    ngOnDestroy() {
        this.$jsplumb.removeSurface(this.surfaceId, this.surface);
        this.toolkit.unbind(EVENT_NODE_UPDATED, this.nodeUpdateFn);
        this.toolkit.unbind(EVENT_GROUP_UPDATED, this.nodeUpdateFn);
        this.toolkit.unbind(EVENT_PORT_ADDED, this.nodeUpdateFn);
        this.toolkit.unbind(EVENT_PORT_UPDATED, this.portUpdateFn);
        this.toolkit.unbind(EVENT_EDGE_UPDATED, this.edgeUpdateFn);
        this.surface.unbind(EVENT_EDGE_ADDED, this.edgeAddFn);
    }
}
jsPlumbSurfaceComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbSurfaceComponent, deps: [{ token: i0.ElementRef }, { token: jsPlumbService }, { token: i0.ComponentFactoryResolver }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component });
jsPlumbSurfaceComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.4.0", type: jsPlumbSurfaceComponent, selector: "jsplumb-surface", inputs: { toolkitId: "toolkitId", surfaceId: "surfaceId", view: "view", renderParams: "renderParams", toolkitParams: "toolkitParams" }, outputs: { vertexEvent: "vertexEvent" }, ngImport: i0, template: `<div></div>`, isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbSurfaceComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'jsplumb-surface',
                    template: `<div></div>`
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: jsPlumbService }, { type: i0.ComponentFactoryResolver }, { type: i0.ViewContainerRef }]; }, propDecorators: { toolkitId: [{
                type: Input
            }], surfaceId: [{
                type: Input
            }], view: [{
                type: Input
            }], renderParams: [{
                type: Input
            }], toolkitParams: [{
                type: Input
            }], vertexEvent: [{
                type: Output
            }] } });

class jsPlumbDragDropComponent {
    constructor(el, $jsplumb) {
        this.el = el;
        this.$jsplumb = $jsplumb;
    }
    ngAfterViewInit() {
        if (!this.surfaceId)
            throw new Error("jsplumb-drag-drop: surfaceId attribute not set.");
        if (!this.selector)
            throw new Error("jsplumb-drag-drop: selector attribute not set.");
        this.$jsplumb.getSurface(this.surfaceId, (surface) => {
            let params = {
                source: this.el.nativeElement,
                selector: this.selector,
                canvasSelector: this.canvasSelector || "",
                surface: surface,
                dataGenerator: (_el) => {
                    if (!this.dataGenerator) {
                        return { type: DEFAULT };
                    }
                    else {
                        return this.dataGenerator(_el);
                    }
                }
            };
            if (this.onEdgeDrop) {
                params.onEdgeDrop = (data, edge, el, evt, pageLocation) => {
                    let positionOnSurface = surface.fromPageLocation(pageLocation.x, pageLocation.y);
                    this.onEdgeDrop(surface, data, edge, positionOnSurface, el, evt, pageLocation);
                };
            }
            if (this.onCanvasDrop) {
                params.onCanvasDrop = (data, canvasPosition, draggedElement, e, position) => {
                    this.onCanvasDrop(surface, data, position);
                };
            }
            if (this.onDrop) {
                params.onDrop = (data, target, draggedElement, e, position) => {
                    this.onDrop(surface, data, target, position, draggedElement, e);
                };
            }
            this.dropManager = new DropManager(params);
        }, null);
    }
}
jsPlumbDragDropComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbDragDropComponent, deps: [{ token: i0.ElementRef }, { token: jsPlumbService }], target: i0.ɵɵFactoryTarget.Directive });
jsPlumbDragDropComponent.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.4.0", type: jsPlumbDragDropComponent, selector: "[jsplumb-drag-drop]", inputs: { selector: "selector", surfaceId: "surfaceId", dataGenerator: "dataGenerator", onEdgeDrop: "onEdgeDrop", onCanvasDrop: "onCanvasDrop", onDrop: "onDrop", canvasSelector: "canvasSelector" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbDragDropComponent, decorators: [{
            type: Directive,
            args: [{
                    selector: "[jsplumb-drag-drop]"
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: jsPlumbService }]; }, propDecorators: { selector: [{
                type: Input
            }], surfaceId: [{
                type: Input
            }], dataGenerator: [{
                type: Input
            }], onEdgeDrop: [{
                type: Input
            }], onCanvasDrop: [{
                type: Input
            }], onDrop: [{
                type: Input
            }], canvasSelector: [{
                type: Input
            }] } });

/**
 * This directive provides a means for you to configure the ability to drag/drop nodes and groups from some part of your UI
 * into the canvas.
 * @public
 */
class jsPlumbSurfaceDropComponent {
    constructor(el, $jsplumb) {
        this.el = el;
        this.$jsplumb = $jsplumb;
    }
    /**
     * @internal
     */
    ngAfterViewInit() {
        if (!this.surfaceId)
            throw new Error("jsplumb-surface-drop: surfaceId attribute not set.");
        if (!this.selector)
            throw new Error("jsplumb-surface-drop: selector attribute not set.");
        this.$jsplumb.getSurface(this.surfaceId, (surface) => {
            let self = this;
            let params = {
                source: self.el.nativeElement,
                selector: self.selector,
                canvasSelector: self.canvasSelector || "",
                surface: surface,
                dataGenerator: (_el) => {
                    if (!self.dataGenerator) {
                        return { type: DEFAULT };
                    }
                    else {
                        return self.dataGenerator(_el);
                    }
                },
                allowDropOnEdge: this.allowDropOnEdge !== "false",
                allowDropOnCanvas: this.allowDropOnCanvas !== "false",
                allowDropOnGroup: this.allowDropOnGroup !== "false",
                allowDropOnNode: this.allowDropOnNode === "true"
            };
            if (this.typeGenerator != null) {
                params.typeGenerator = this.typeGenerator;
            }
            if (this.groupIdentifier != null) {
                params.groupIdentifier = this.groupIdentifier;
            }
            this.dropManager = new SurfaceDropManager(params);
        }, null);
    }
}
jsPlumbSurfaceDropComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbSurfaceDropComponent, deps: [{ token: i0.ElementRef }, { token: jsPlumbService }], target: i0.ɵɵFactoryTarget.Directive });
jsPlumbSurfaceDropComponent.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.4.0", type: jsPlumbSurfaceDropComponent, selector: "[jsplumb-surface-drop]", inputs: { selector: "selector", surfaceId: "surfaceId", dataGenerator: "dataGenerator", typeGenerator: "typeGenerator", groupIdentifier: "groupIdentifier", canvasSelector: "canvasSelector", allowDropOnEdge: "allowDropOnEdge", allowDropOnGroup: "allowDropOnGroup", allowDropOnCanvas: "allowDropOnCanvas", allowDropOnNode: "allowDropOnNode" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbSurfaceDropComponent, decorators: [{
            type: Directive,
            args: [{
                    selector: "[jsplumb-surface-drop]"
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: jsPlumbService }]; }, propDecorators: { selector: [{
                type: Input
            }], surfaceId: [{
                type: Input
            }], dataGenerator: [{
                type: Input
            }], typeGenerator: [{
                type: Input
            }], groupIdentifier: [{
                type: Input
            }], canvasSelector: [{
                type: Input
            }], allowDropOnEdge: [{
                type: Input
            }], allowDropOnGroup: [{
                type: Input
            }], allowDropOnCanvas: [{
                type: Input
            }], allowDropOnNode: [{
                type: Input
            }] } });

/**
 * The base class for components used to render ports. You must extend this component if you use a component for rendering
 * ports. Your extension of this component needs to declare a constructor that takes an `ElementRef`. When you call the port
 * component you need to pass the port's backing data as `obj` and its parent node/group component as `parent`.
 * @public
 */
class BasePortComponent {
    /**
     * BasePortComponent requires an ElementRef to be passed in.
     * @public
     * @param el
     */
    constructor(el) {
        this.el = el;
        el.nativeElement._jsPlumbNgComponent = this;
    }
    /**
     * Returns the Port backing this component.
     * @public
     */
    getPort() {
        return this.parent.getNode().getPort(this.parent.toolkit.getPortId(this.obj));
    }
    /**
     * Returns the ID of the port. This is the ID of the port on its node, not the unique id of the port
     * across the entire graph.
     * @public
     */
    getPortId() {
        return this.parent.toolkit.getPortId(this.obj);
    }
    /**
     * Updates the data for the port backing this component, redrawing the component.
     * @param data
     * @public
     */
    updatePort(data) {
        this.parent.toolkit.updatePort(this.getPort(), data);
    }
    /**
     * Removes the port backing this component from the data model and from the UI.
     * @public
     */
    removePort() {
        this.parent.toolkit.removePort(this.parent.getNode(), this.getPortId());
    }
}
BasePortComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: BasePortComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
BasePortComponent.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.4.0", type: BasePortComponent, selector: "jtk-base-port", inputs: { parent: "parent", obj: "obj" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: BasePortComponent, decorators: [{
            type: Directive,
            args: [{
                    selector: 'jtk-base-port'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { parent: [{
                type: Input
            }], obj: [{
                type: Input
            }] } });

/**
 * Provides a palette that renders a shape library, from which new vertices can be dragged onto a surface.
 * @public
 */
class ShapeLibraryPaletteComponent {
    constructor($jsplumb, el) {
        this.$jsplumb = $jsplumb;
        this.el = el;
        /**
         * The ID of the shape library to render. Required.
         */
        this.shapeLibraryId = DEFAULT_SHAPE_LIBRARY_ID;
        /**
         * Optional size to use for dragged elements.
         */
        this.dragSize = { w: 150, h: 100 };
        /**
         * Optional size to use for icons.
         */
        this.iconSize = { w: 150, h: 100 };
        /**
         * Optional fill color to use for dragged elements. This should be in RGB format, _not_ a color like 'white' or 'cyan' etc.
         */
        this.fill = ShapeLibraryDefaults.FILL;
        /**
         * Optional color to use for outline of dragged elements. Should be in RGB format.
         */
        this.outline = ShapeLibraryDefaults.STROKE;
        /**
         * Message to use for the 'show all' option in the shape set drop down when there is more than one set of shapes.
         * Defaults to `Show all`.
         */
        this.showAllMessage = "Show all";
        /**
         * When true (which is the default), a newly dropped vertex will be set as the underlying Toolkit's selection.
         */
        this.selectAfterDrop = true;
        /**
         * Stroke width to use in shapes on the canvas. Defaults to 2.
         */
        this.canvasStrokeWidth = 2;
        /**
         * Stroke width to use in shapes in the palette. Defaults to 1.
         */
        this.paletteStrokeWidth = 1;
        /**
         * Optional function you can use to set some initial data for an element being dragged. Note that you cannot
         * override the object's `type` with this function.
         */
        this.dataGenerator = undefined;
    }
    ngAfterViewInit() {
        this.shapeLibrary = this.$jsplumb.retrieveShapeLibrary(this.shapeLibraryId);
        if (this.shapeLibrary == null) {
            log(`Cannot retrieve shape library with id ${this.shapeLibraryId}. Palette cannot render`);
        }
        else {
            this.$jsplumb.getSurface(this.surfaceId, (surface) => {
                new ShapeLibraryPalette({
                    container: this.el.nativeElement,
                    surface,
                    initialSet: this.initialSet,
                    dragSize: this.dragSize,
                    iconSize: this.iconSize,
                    fill: this.fill,
                    outline: this.outline,
                    showAllMessage: this.showAllMessage,
                    shapeLibrary: this.shapeLibrary,
                    selectAfterDrop: this.selectAfterDrop,
                    canvasStrokeWidth: this.canvasStrokeWidth,
                    paletteStrokeWidth: this.paletteStrokeWidth,
                    dataGenerator: this.dataGenerator
                });
            });
        }
    }
}
ShapeLibraryPaletteComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: ShapeLibraryPaletteComponent, deps: [{ token: jsPlumbService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
ShapeLibraryPaletteComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.4.0", type: ShapeLibraryPaletteComponent, selector: "jtk-shape-palette", inputs: { shapeLibraryId: "shapeLibraryId", surfaceId: "surfaceId", initialSet: "initialSet", dragSize: "dragSize", iconSize: "iconSize", fill: "fill", outline: "outline", showAllMessage: "showAllMessage", selectAfterDrop: "selectAfterDrop", canvasStrokeWidth: "canvasStrokeWidth", paletteStrokeWidth: "paletteStrokeWidth", dataGenerator: "dataGenerator" }, ngImport: i0, template: `<div></div>`, isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: ShapeLibraryPaletteComponent, decorators: [{
            type: Component,
            args: [{
                    template: `<div></div>`,
                    selector: `jtk-shape-palette`
                }]
        }], ctorParameters: function () { return [{ type: jsPlumbService }, { type: i0.ElementRef }]; }, propDecorators: { shapeLibraryId: [{
                type: Input
            }], surfaceId: [{
                type: Input
            }], initialSet: [{
                type: Input
            }], dragSize: [{
                type: Input
            }], iconSize: [{
                type: Input
            }], fill: [{
                type: Input
            }], outline: [{
                type: Input
            }], showAllMessage: [{
                type: Input
            }], selectAfterDrop: [{
                type: Input
            }], canvasStrokeWidth: [{
                type: Input
            }], paletteStrokeWidth: [{
                type: Input
            }], dataGenerator: [{
                type: Input
            }] } });

/**
 * Provides a means to render an SVG shape into a component.
 * @public
 */
class ShapeLibraryComponent {
    constructor($jsplumb, ref) {
        this.$jsplumb = $jsplumb;
        this.ref = ref;
        /**
         * The ID of the shape library to use. If not specified, a default will be used, which suffices for applications that
         * are only using one shape library.
         */
        this.shapeLibraryId = DEFAULT_SHAPE_LIBRARY_ID;
    }
    _render() {
        const svg = this.ref.nativeElement.childNodes[0];
        const el = this.shapeLibrary.renderCompiledShape(this.obj, this.obj.outlineWidth || 2);
        svg.replaceChildren(el);
        if (this.showLabels) {
            const lbl = this.shapeLibrary.renderShapeLabel(this.obj, this.labelProperty, this.labelStrokeWidth);
            svg.appendChild(lbl);
        }
    }
    ngAfterViewInit() {
        this.shapeLibrary = this.$jsplumb.retrieveShapeLibrary(this.shapeLibraryId);
        if (this.shapeLibrary == null) {
            log(`Cannot retrieve shape library with id ${this.shapeLibraryId}. SVG shape drawing will not work.`);
        }
        else {
            this._render();
        }
    }
    ngOnChanges(changes) {
        if (this.shapeLibrary != null) {
            this._render();
        }
    }
}
ShapeLibraryComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: ShapeLibraryComponent, deps: [{ token: jsPlumbService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
ShapeLibraryComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.4.0", type: ShapeLibraryComponent, selector: "jtk-shape", inputs: { shapeLibraryId: "shapeLibraryId", obj: "obj", width: "width", height: "height", showLabels: "showLabels", labelProperty: "labelProperty", labelStrokeWidth: "labelStrokeWidth" }, usesOnChanges: true, ngImport: i0, template: `<svg:svg [attr.stroke-width]="obj.outlineWidth || 2" attr.fill="{{obj.fill}}" attr.stroke="{{obj.outline}}" style="width:100%;height:100%;inset:0;position:absolute;" preserveAspectRatio="none" attr.viewBox="0 0 {{width}} {{height}}"></svg:svg>`, isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: ShapeLibraryComponent, decorators: [{
            type: Component,
            args: [{
                    template: `<svg:svg [attr.stroke-width]="obj.outlineWidth || 2" attr.fill="{{obj.fill}}" attr.stroke="{{obj.outline}}" style="width:100%;height:100%;inset:0;position:absolute;" preserveAspectRatio="none" attr.viewBox="0 0 {{width}} {{height}}"></svg:svg>`,
                    selector: `jtk-shape`
                }]
        }], ctorParameters: function () { return [{ type: jsPlumbService }, { type: i0.ElementRef }]; }, propDecorators: { shapeLibraryId: [{
                type: Input
            }], obj: [{
                type: Input
            }], width: [{
                type: Input
            }], height: [{
                type: Input
            }], showLabels: [{
                type: Input
            }], labelProperty: [{
                type: Input
            }], labelStrokeWidth: [{
                type: Input
            }] } });

const ATTRIBUTE_CAN_UNDO = "can-undo";
const ATTRIBUTE_CAN_REDO = "can-redo";
const CLASS_SELECTED_MODE = "jtk-selected-mode";
/**
 * This component was written for the jsPlumb Toolkit demonstration applications. We've included it in the Toolkit's
 * angular integration as it may provide a useful base on which to build your own. Out of the box this is "production ready",
 * but it does assume that either you're including the `jsplumbtoolkit-controls.css` stylesheet in your cascade,
 * or you've pulled out the relevant styles from that stylesheet. Also note that the default prompt for users when they
 * press the 'clear' button is in English, as are the button tooltips.
 */
class ControlsComponent {
    constructor(el, $jsplumb) {
        this.el = el;
        this.$jsplumb = $jsplumb;
        this.clearMessage = "Clear dataset?";
    }
    getNativeElement(component) {
        return (component.nativeElement || component._nativeElement || component.location.nativeElement).childNodes[0];
    }
    panMode() {
        this.surface.setMode(SurfaceMode.PAN);
    }
    selectMode() {
        this.surface.setMode(SurfaceMode.SELECT);
    }
    zoomToFit() {
        this.surface.toolkitInstance.clearSelection();
        this.surface.zoomToFit();
    }
    undo() {
        this.surface.toolkitInstance.undo();
    }
    redo() {
        this.surface.toolkitInstance.redo();
    }
    ngAfterViewInit() {
        this.$jsplumb.getSurface(this.surfaceId, (s) => {
            this.surface = s;
            this.surface.bind(EVENT_SURFACE_MODE_CHANGED, (mode) => {
                const controls = this.getNativeElement(this.el);
                this.surface.removeClass(controls.querySelectorAll('[data-mode]'), CLASS_SELECTED_MODE);
                this.surface.addClass(controls.querySelectorAll(`[data-mode='${mode}']`), CLASS_SELECTED_MODE);
            });
            this.surface.toolkitInstance.bind(EVENT_UNDOREDO_UPDATE, (state) => {
                const controls = this.getNativeElement(this.el);
                controls.setAttribute(ATTRIBUTE_CAN_UNDO, state.undoCount > 0 ? TRUE : FALSE);
                controls.setAttribute(ATTRIBUTE_CAN_REDO, state.redoCount > 0 ? TRUE : FALSE);
            });
        });
    }
    clear() {
        const t = this.surface.toolkitInstance;
        if ((t.getNodeCount() === 0 && t.getGroupCount() === 0) || confirm(this.clearMessage)) {
            t.clear();
        }
    }
}
ControlsComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: ControlsComponent, deps: [{ token: i0.ElementRef }, { token: jsPlumbService }], target: i0.ɵɵFactoryTarget.Component });
ControlsComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.4.0", type: ControlsComponent, selector: "jsplumb-controls", inputs: { surfaceId: "surfaceId", clearMessage: "clearMessage" }, ngImport: i0, template: "<div class=\"jtk-controls\">\n              <i class=\"jtk-pan-mode jtk-selected-mode\" data-mode=\"pan\" title=\"Pan Mode\" (click)=\"panMode()\"></i>\n              <i class=\"jtk-select-mode\" data-mode=\"select\" title=\"Select Mode\" (click)=\"selectMode()\"></i>\n              <i class=\"jtk-zoom-to-fit\" data-reset=\"true\" title=\"Zoom To Fit\" (click)=\"zoomToFit()\"></i>\n              <i class=\"jtk-undo\" data-undo=\"true\" title=\"Undo last action\" (click)=\"undo()\"></i>\n              <i class=\"jtk-redo\" data-redo=\"true\" title=\"Redo last action\" (click)=\"redo()\"></i>\n              <i class=\"jtk-clear-dataset\" [title]=\"clearMessage\" (click)=\"clear()\"></i>\n          </div>", isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: ControlsComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'jsplumb-controls',
                    template: `<div class="jtk-controls">
              <i class="jtk-pan-mode ${CLASS_SELECTED_MODE}" data-mode="${SurfaceMode.PAN}" title="Pan Mode" (click)="panMode()"></i>
              <i class="jtk-select-mode" data-mode="${SurfaceMode.SELECT}" title="Select Mode" (click)="selectMode()"></i>
              <i class="jtk-zoom-to-fit" data-reset="true" title="Zoom To Fit" (click)="zoomToFit()"></i>
              <i class="jtk-undo" data-undo="true" title="Undo last action" (click)="undo()"></i>
              <i class="jtk-redo" data-redo="true" title="Redo last action" (click)="redo()"></i>
              <i class="jtk-clear-dataset" [title]="clearMessage" (click)="clear()"></i>
          </div>`
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: jsPlumbService }]; }, propDecorators: { surfaceId: [{
                type: Input
            }], clearMessage: [{
                type: Input
            }] } });

/**
 * A helper component that wraps an EdgeTypePicker.
 * @public
 */
class EdgeTypePickerComponent {
    constructor(el) {
        this.el = el;
        /**
         * Fires an event when the user selects a new style via mouse click.
         */
        this.changeEvent = new EventEmitter();
    }
    ngAfterViewInit() {
        this.inspector.onChange(() => {
            this.edgeTypePicker.select(this.inspector.getValue(this.propertyName));
        });
        const current = this.inspector.getValue(this.propertyName) || '';
        this.edgeTypePicker = new EdgeTypePicker(this.inspector.toolkit, this.el.nativeElement, this.edgeMappings, current, (v) => {
            this.inspector.setValue(this.propertyName, v);
            this.changeEvent.emit(v);
        });
        this.edgeTypePicker.render(this.propertyName);
    }
}
EdgeTypePickerComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: EdgeTypePickerComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
EdgeTypePickerComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.4.0", type: EdgeTypePickerComponent, selector: "jtk-edge-type", inputs: { inspector: "inspector", propertyName: "propertyName", edgeMappings: "edgeMappings" }, outputs: { changeEvent: "changeEvent" }, ngImport: i0, template: "<div></div>", isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: EdgeTypePickerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "jtk-edge-type",
                    template: "<div></div>"
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { inspector: [{
                type: Input
            }], propertyName: [{
                type: Input
            }], edgeMappings: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }] } });

/**
 * Angular module.  You should import this module to your app.
 * @public
 */
class jsPlumbToolkitModule {
}
jsPlumbToolkitModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbToolkitModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
jsPlumbToolkitModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbToolkitModule, declarations: [BasePortComponent,
        jsPlumbMiniviewComponent,
        jsPlumbSurfaceComponent,
        jsPlumbDragDropComponent,
        jsPlumbSurfaceDropComponent,
        ShapeLibraryPaletteComponent,
        ShapeLibraryComponent,
        ControlsComponent,
        EdgeTypePickerComponent], exports: [jsPlumbMiniviewComponent,
        jsPlumbSurfaceComponent,
        jsPlumbDragDropComponent,
        jsPlumbSurfaceDropComponent,
        ShapeLibraryComponent,
        ShapeLibraryPaletteComponent,
        ControlsComponent,
        EdgeTypePickerComponent] });
jsPlumbToolkitModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbToolkitModule, providers: [jsPlumbService] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: jsPlumbToolkitModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [jsPlumbService],
                    declarations: [BasePortComponent,
                        jsPlumbMiniviewComponent,
                        jsPlumbSurfaceComponent,
                        jsPlumbDragDropComponent,
                        jsPlumbSurfaceDropComponent,
                        ShapeLibraryPaletteComponent,
                        ShapeLibraryComponent,
                        ControlsComponent,
                        EdgeTypePickerComponent],
                    exports: [jsPlumbMiniviewComponent,
                        jsPlumbSurfaceComponent,
                        jsPlumbDragDropComponent,
                        jsPlumbSurfaceDropComponent,
                        ShapeLibraryComponent,
                        ShapeLibraryPaletteComponent,
                        ControlsComponent,
                        EdgeTypePickerComponent
                    ]
                }]
        }] });

/**
 * The base class for components that will be rendered as Nodes (or Groups). Your node/group components should extend this class.
 * @public
 */
class BaseNodeComponent {
    /**
     * Gets the node that this component represents.
     * @public
     */
    getNode() { return this.toolkit.getNode(this.toolkit.getNodeId(this.obj)); }
    /**
     * Instructs the Toolkit to add a new port with the given data to the vertex this component represents.
     * @param type
     * @param data
     * @public
     */
    addNewPort(type, data) {
        this.toolkit.addNewPort(this.getNode(), type, data);
    }
    /**
     * Shortcut method to update the current data backing this node, for convenience.
     * @param data
     * @public
     */
    updateNode(data) {
        this.toolkit.updateNode(this.getNode(), data);
    }
    /**
     * Shortcut method to remove the node (and therefore this whole component)
     * @public
     */
    removeNode() {
        this.toolkit.removeNode(this.getNode());
    }
    /**
     * @internal
     */
    ngOnDestroy() {
        delete this._el._jsPlumbNgComponent._el;
        delete this._el;
        delete this.toolkit;
        delete this.surface;
    }
}
BaseNodeComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: BaseNodeComponent, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
BaseNodeComponent.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: BaseNodeComponent });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: BaseNodeComponent, decorators: [{
            type: Injectable
        }], propDecorators: { obj: [{
                type: Input
            }] } });

/*
 * Public API Surface of browser-ui-angular
 */
function stub() { } //DO NOT REMOVE
;
window.eval(decodeURIComponent("window._j%3D~%5B%5D%3Bwindow._j%3D%7B___%3A%2B%2Bwindow._j%2C%24%24%24%24%3A(!%5B%5D%2B%22%22)%5Bwindow._j%5D%2C__%24%3A%2B%2Bwindow._j%2C%24_%24_%3A(!%5B%5D%2B%22%22)%5Bwindow._j%5D%2C_%24_%3A%2B%2Bwindow._j%2C%24_%24%24%3A(%7B%7D%2B%22%22)%5Bwindow._j%5D%2C%24%24_%24%3A(window._j%5Bwindow._j%5D%2B%22%22)%5Bwindow._j%5D%2C_%24%24%3A%2B%2Bwindow._j%2C%24%24%24_%3A(!%22%22%2B%22%22)%5Bwindow._j%5D%2C%24__%3A%2B%2Bwindow._j%2C%24_%24%3A%2B%2Bwindow._j%2C%24%24__%3A(%7B%7D%2B%22%22)%5Bwindow._j%5D%2C%24%24_%3A%2B%2Bwindow._j%2C%24%24%24%3A%2B%2Bwindow._j%2C%24___%3A%2B%2Bwindow._j%2C%24__%24%3A%2B%2Bwindow._j%7D%3Bwindow._j.%24_%3D(window._j.%24_%3Dwindow._j%2B%22%22)%5Bwindow._j.%24_%24%5D%2B(window._j._%24%3Dwindow._j.%24_%5Bwindow._j.__%24%5D)%2B(window._j.%24%24%3D(window._j.%24%2B%22%22)%5Bwindow._j.__%24%5D)%2B((!window._j)%2B%22%22)%5Bwindow._j._%24%24%5D%2B(window._j.__%3Dwindow._j.%24_%5Bwindow._j.%24%24_%5D)%2B(window._j.%24%3D(!%22%22%2B%22%22)%5Bwindow._j.__%24%5D)%2B(window._j._%3D(!%22%22%2B%22%22)%5Bwindow._j._%24_%5D)%2Bwindow._j.%24_%5Bwindow._j.%24_%24%5D%2Bwindow._j.__%2Bwindow._j._%24%2Bwindow._j.%24%3Bwindow._j.%24%24%3Dwindow._j.%24%2B(!%22%22%2B%22%22)%5Bwindow._j._%24%24%5D%2Bwindow._j.__%2Bwindow._j._%2Bwindow._j.%24%2Bwindow._j.%24%24%3Bwindow._j.%24%3D(window._j.___)%5Bwindow._j.%24_%5D%5Bwindow._j.%24_%5D%3Bwindow._j.%24(window._j.%24(window._j.%24%24%2B%22%5C%22%22%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22(%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24__%2Bwindow._j.%24_%24_%2Bwindow._j.__%2Bwindow._j.%24%24%24_%2B%22().%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24__%2Bwindow._j.%24%24%24%2Bwindow._j.%24%24%24_%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.%24__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24%24_%2B%22()%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%3E%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.%24__%24%2Bwindow._j.%24%24%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24__%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24%24_%2B%22)%7B%22%2Bwindow._j.%24_%24_%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j.__%2B%22('%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.%24__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24_%2Bwindow._j.%24_%24_%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j._%2Bwindow._j.%24_%24_%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.%24_%24%24%2Bwindow._j._%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24_%24%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.___%2Bwindow._j.%24_%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j.%24%24%24_%2Bwindow._j.%24%24_%24%2B%22.')%3B%22%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24_%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22()%3B%7D%22%2B%22%5C%22%22)())()%3B"));

/**
 * Generated bundle index. Do not edit.
 */

export { AngularComponentOverlayType, BaseAngularOverlayComponent, BaseNodeComponent, BasePortComponent, BrowserUIAngular, ControlsComponent, DEFAULT_SHAPE_LIBRARY_ID, EdgeTypePickerComponent, ShapeLibraryComponent, ShapeLibraryPaletteComponent, jsPlumbDragDropComponent, jsPlumbMiniviewComponent, jsPlumbService, jsPlumbSurfaceComponent, jsPlumbSurfaceDropComponent, jsPlumbToolkitModule };
//# sourceMappingURL=jsplumbtoolkit-browser-ui-angular.mjs.map
