/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@jsplumbtoolkit/browser-ui-angular" />
export * from './index-1715197564106';
