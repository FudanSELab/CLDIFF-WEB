import { JsPlumbToolkit, Vertex, Node, ObjectData, jsPlumbToolkitDOMElement, Surface } from "@jsplumbtoolkit/browser-ui";
import * as i0 from "@angular/core";
/**
 * The base class for components that will be rendered as Nodes (or Groups). Your node/group components should extend this class.
 * @public
 */
export declare abstract class BaseNodeComponent {
    toolkit: JsPlumbToolkit;
    surface: Surface;
    _el: jsPlumbToolkitDOMElement;
    modelObject: Vertex;
    /**
    * Data object for the node
    * @public
    */
    obj: ObjectData;
    /**
     * Gets the node that this component represents.
     * @public
     */
    getNode(): Node;
    /**
     * Instructs the Toolkit to add a new port with the given data to the vertex this component represents.
     * @param type
     * @param data
     * @public
     */
    addNewPort(type: string, data: ObjectData): void;
    /**
     * Shortcut method to update the current data backing this node, for convenience.
     * @param data
     * @public
     */
    updateNode(data: ObjectData): void;
    /**
     * Shortcut method to remove the node (and therefore this whole component)
     * @public
     */
    removeNode(): void;
    /**
     * @internal
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseNodeComponent, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseNodeComponent>;
}
