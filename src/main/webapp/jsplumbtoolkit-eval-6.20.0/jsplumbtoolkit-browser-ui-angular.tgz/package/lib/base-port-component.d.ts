import { ObjectData, Port } from "@jsplumbtoolkit/browser-ui";
import { BaseNodeComponent } from "./base-node-component";
import { ElementRef } from "@angular/core";
import * as i0 from "@angular/core";
/**
 * The base class for components used to render ports. You must extend this component if you use a component for rendering
 * ports. Your extension of this component needs to declare a constructor that takes an `ElementRef`. When you call the port
 * component you need to pass the port's backing data as `obj` and its parent node/group component as `parent`.
 * @public
 */
export declare class BasePortComponent {
    el: ElementRef;
    /**
     * Parent node (or group) component. Required.
     * @public
     */
    parent: BaseNodeComponent;
    /**
     * Data object for the port. Required.
     * @public
     */
    obj: ObjectData;
    /**
     * BasePortComponent requires an ElementRef to be passed in.
     * @public
     * @param el
     */
    constructor(el: ElementRef);
    /**
     * Returns the Port backing this component.
     * @public
     */
    getPort(): Port;
    /**
     * Returns the ID of the port. This is the ID of the port on its node, not the unique id of the port
     * across the entire graph.
     * @public
     */
    getPortId(): string;
    /**
     * Updates the data for the port backing this component, redrawing the component.
     * @param data
     * @public
     */
    updatePort(data: ObjectData): void;
    /**
     * Removes the port backing this component from the data model and from the UI.
     * @public
     */
    removePort(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BasePortComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BasePortComponent, "jtk-base-port", never, { "parent": "parent"; "obj": "obj"; }, {}, never>;
}
