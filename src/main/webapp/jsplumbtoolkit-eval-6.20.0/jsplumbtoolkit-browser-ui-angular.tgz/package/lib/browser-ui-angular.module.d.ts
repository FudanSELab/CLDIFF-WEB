import * as i0 from "@angular/core";
import * as i1 from "./base-port-component";
import * as i2 from "./miniview-component";
import * as i3 from "./surface-component";
import * as i4 from "./drop-component";
import * as i5 from "./surface-drop-component";
import * as i6 from "./shape.library.palette.component";
import * as i7 from "./shape.library.component";
import * as i8 from "./controls-component";
import * as i9 from "./edge.type.picker.component";
/**
 * Angular module.  You should import this module to your app.
 * @public
 */
export declare class jsPlumbToolkitModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<jsPlumbToolkitModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<jsPlumbToolkitModule, [typeof i1.BasePortComponent, typeof i2.jsPlumbMiniviewComponent, typeof i3.jsPlumbSurfaceComponent, typeof i4.jsPlumbDragDropComponent, typeof i5.jsPlumbSurfaceDropComponent, typeof i6.ShapeLibraryPaletteComponent, typeof i7.ShapeLibraryComponent, typeof i8.ControlsComponent, typeof i9.EdgeTypePickerComponent], never, [typeof i2.jsPlumbMiniviewComponent, typeof i3.jsPlumbSurfaceComponent, typeof i4.jsPlumbDragDropComponent, typeof i5.jsPlumbSurfaceDropComponent, typeof i7.ShapeLibraryComponent, typeof i6.ShapeLibraryPaletteComponent, typeof i8.ControlsComponent, typeof i9.EdgeTypePickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<jsPlumbToolkitModule>;
}
