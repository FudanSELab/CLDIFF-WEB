import { SurfaceRenderOptions, SurfaceViewOptions, ViewNodeOptions, ViewOptionsEntry, ViewPortOptions } from "@jsplumbtoolkit/browser-ui";
/**
 * Extension of node definition in a view that adds `component`.
 * @public
 */
export interface ViewNodeAngularOptions extends ViewNodeOptions {
    /**
     * Reference to the Angular component class used to render this node type.
     */
    component?: any;
}
/**
 * Extension of group definition in a view that adds `component`.
 * @public
 */
export interface ViewGroupAngularOptions extends ViewNodeAngularOptions {
}
/**
 * Extension of port definition in a view that adds `component`.
 * @public
 */
export interface ViewPortAngularOptions extends ViewPortOptions {
    /**
     * Reference to the Angular component class used to render this port type.
     */
    component?: any;
}
/**
 * Extension of view options that allows for Angular components to be mapped to node, group and port types.
 * @public
 */
export interface AngularViewOptions extends SurfaceViewOptions {
    nodes?: ViewOptionsEntry<ViewNodeAngularOptions>;
    groups?: ViewOptionsEntry<ViewGroupAngularOptions>;
    ports?: ViewOptionsEntry<ViewPortAngularOptions>;
}
/**
 * Render options for a Surface when used with Angular integration. Some values from the original SurfaceRenderOptions are not relevant.
 * @public
 */
export interface AngularRenderOptions extends Pick<SurfaceRenderOptions, Exclude<keyof SurfaceRenderOptions, ["view", "tags", "container", "directRender", "storePositionsInModel"]>> {
}
/**
 * The default ID of a shape library stored/retrieved on the surface. If your app only uses one shape library you wont need to
 * provide a shapeLibraryId to your shape palette or shape components.
 */
export declare const DEFAULT_SHAPE_LIBRARY_ID = "shapeLibrary";
