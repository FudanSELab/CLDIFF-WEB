import { AfterViewInit, ElementRef } from '@angular/core';
import { Surface } from '@jsplumbtoolkit/browser-ui';
import { jsPlumbService } from './jsplumbtoolkit-service';
import * as i0 from "@angular/core";
/**
 * This component was written for the jsPlumb Toolkit demonstration applications. We've included it in the Toolkit's
 * angular integration as it may provide a useful base on which to build your own. Out of the box this is "production ready",
 * but it does assume that either you're including the `jsplumbtoolkit-controls.css` stylesheet in your cascade,
 * or you've pulled out the relevant styles from that stylesheet. Also note that the default prompt for users when they
 * press the 'clear' button is in English, as are the button tooltips.
 */
export declare class ControlsComponent implements AfterViewInit {
    private el;
    private $jsplumb;
    surfaceId: string;
    clearMessage: string;
    surface: Surface;
    constructor(el: ElementRef, $jsplumb: jsPlumbService);
    getNativeElement(component: any): any;
    panMode(): void;
    selectMode(): void;
    zoomToFit(): void;
    undo(): void;
    redo(): void;
    ngAfterViewInit(): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ControlsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ControlsComponent, "jsplumb-controls", never, { "surfaceId": "surfaceId"; "clearMessage": "clearMessage"; }, {}, never, never>;
}
