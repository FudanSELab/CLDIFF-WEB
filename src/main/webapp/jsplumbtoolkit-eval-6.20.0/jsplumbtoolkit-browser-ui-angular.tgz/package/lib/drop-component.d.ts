import { ElementRef } from "@angular/core";
import { jsPlumbService } from "./jsplumbtoolkit-service";
import { DataGeneratorFunction, DropManager, Edge, Group, Node, PointXY, Surface } from "@jsplumbtoolkit/browser-ui";
import * as i0 from "@angular/core";
export declare class jsPlumbDragDropComponent<T> {
    private el;
    private $jsplumb;
    constructor(el: ElementRef, $jsplumb: jsPlumbService);
    selector: string;
    surfaceId: string;
    dataGenerator: DataGeneratorFunction<T>;
    dropManager: DropManager<T>;
    onEdgeDrop: (surface: Surface, data: any, edge: Edge, positionOnSurface: PointXY, e: Element, evt: Event, pageLocation: PointXY) => any;
    onCanvasDrop: (surface: Surface, data: any, position: PointXY) => any;
    onDrop: (surface: Surface, data: any, target: Node | Group, position: PointXY, draggedElement: HTMLElement, e: Event) => any;
    canvasSelector: string;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<jsPlumbDragDropComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<jsPlumbDragDropComponent<any>, "[jsplumb-drag-drop]", never, { "selector": "selector"; "surfaceId": "surfaceId"; "dataGenerator": "dataGenerator"; "onEdgeDrop": "onEdgeDrop"; "onCanvasDrop": "onCanvasDrop"; "onDrop": "onDrop"; "canvasSelector": "canvasSelector"; }, {}, never>;
}
