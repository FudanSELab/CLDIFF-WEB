import { AfterViewInit, ElementRef, EventEmitter } from "@angular/core";
import { EdgePropertyMappings, Inspector } from "@jsplumbtoolkit/browser-ui";
import * as i0 from "@angular/core";
/**
 * A helper component that wraps an EdgeTypePicker.
 * @public
 */
export declare class EdgeTypePickerComponent implements AfterViewInit {
    private el;
    /**
     * Associated inspector. Required.
     */
    inspector: Inspector;
    /**
     * The name of the property that maps the edge type.
     */
    propertyName: string;
    /**
     * Set of edge property mappings to render and allow the user to select from.
     */
    edgeMappings: EdgePropertyMappings;
    /**
     * Fires an event when the user selects a new style via mouse click.
     */
    changeEvent: EventEmitter<string>;
    private edgeTypePicker;
    constructor(el: ElementRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EdgeTypePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EdgeTypePickerComponent, "jtk-edge-type", never, { "inspector": "inspector"; "propertyName": "propertyName"; "edgeMappings": "edgeMappings"; }, { "changeEvent": "changeEvent"; }, never, never>;
}
