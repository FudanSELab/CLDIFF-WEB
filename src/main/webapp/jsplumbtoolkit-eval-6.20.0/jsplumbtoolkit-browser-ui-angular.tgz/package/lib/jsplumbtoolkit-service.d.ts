import { BrowserUIBase, Surface, SurfaceOptions, SurfaceRenderOptions, JsPlumbToolkitOptions, MiniviewPluginOptions, ShapeLibraryImpl, ShapeSet, ObjectData, SvgExportOptions, ShapeLibrary, SvgExportUIOptions, ImageExportOptions, ImageExportUIOptions, ImageReadyFunction } from "@jsplumbtoolkit/browser-ui";
import * as i0 from "@angular/core";
/**
 * Options for SVG export.
 * @public
 */
export interface AngularSvgExportOptions<T extends ObjectData> extends SvgExportOptions {
    /**
     * Surface to export
     */
    surface: Surface;
    /**
     * Optional ShapeLibrary to use. If not supplied, supply `shapeLibraryId` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibrary?: ShapeLibrary<T>;
    /**
     * Optional ID of a ShapeLibrary to use - must have been registered on the jsPlumb Angular service via the `registerShapeLibrary` method. If not supplied,
     * supply `shapeLibrary` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibraryId?: string;
}
/**
 * Options for showing the SVG export UI.
 * @public
 */
export interface AngularSvgExportUIOptions<T extends ObjectData> extends SvgExportUIOptions {
    /**
     * Surface to export
     */
    surface: Surface;
    /**
     * Optional ShapeLibrary to use. If not supplied, supply `shapeLibraryId` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibrary?: ShapeLibrary<T>;
    /**
     * Optional ID of a ShapeLibrary to use - must have been registered on the jsPlumb Angular service via the `registerShapeLibrary` method. If not supplied,
     * supply `shapeLibrary` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibraryId?: string;
}
/**
 * Options for image export from some Surface.
 * @public
 */
export interface AngularImageExportOptions<T extends ObjectData> extends ImageExportOptions {
    /**
     * Surface to export
     */
    surface: Surface;
    /**
     * Optional ShapeLibrary to use. If not supplied, supply `shapeLibraryId` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibrary?: ShapeLibrary<T>;
    /**
     * Optional ID of a ShapeLibrary to use - must have been registered on the jsPlumb Angular service via the `registerShapeLibrary` method. If not supplied,
     * supply `shapeLibrary` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibraryId?: string;
}
/**
 * Options for showing the image export UI.
 */
export interface AngularImageExportUIOptions<T extends ObjectData> extends ImageExportUIOptions {
    /**
     * Surface to export
     */
    surface: Surface;
    /**
     * Optional ShapeLibrary to use. If not supplied, supply `shapeLibraryId` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibrary?: ShapeLibrary<T>;
    /**
     * Optional ID of a ShapeLibrary to use - must have been registered on the jsPlumb Angular service via the `registerShapeLibrary` method. If not supplied,
     * supply `shapeLibrary` - or ensure the Surface you are exporting has a ShapeLibrary registered on it.
     */
    shapeLibraryId?: string;
}
/**
 * Angular specific renderer.
 * @public
 */
export declare class BrowserUIAngular extends BrowserUIBase {
    render(container: Element, options?: SurfaceRenderOptions): Surface;
}
/**
 * The jsPlumbService provides the core of the Angular integration, offering methods to create and retrieve instances of the Toolkit.
 * @public
 */
export declare class jsPlumbService {
    /**
     * datastore for user set values.
     */
    private data;
    /**
     * Create (or get if existing) a Toolkit instance.
     * @param id ID of the instance to either create or retrieve.
     * @param params Optional constructor options for the Toolkit instance.
     * @public
     */
    getToolkit(id: string, params?: JsPlumbToolkitOptions): BrowserUIAngular;
    /**
     * Registers a surface. This method is for internal use.
     * @param id
     * @param surface
     * @internal
     */
    addSurface(id: string, surface: Surface): void;
    /**
     * Removes the given surface. For internal use.
     * @param id
     * @param surface
     * @internal
     */
    removeSurface(id: string, surface: Surface): void;
    /**
     * Gets the surface with the given id, passing it to the supplied callback function. If a surface with the given ID does
     * not exist, the request is queued, and then if a surface with the given ID is subsequently registered, each callback
     * for that surface registered via this method is executed in turn.
     * @param id ID of the surface to retrieve
     * @param callback Function to call when the surface has been retrieved.
     * @param _params Optional parameters to pass back into the callback upon successful retrieval of the surface.
     * @public
     */
    getSurface(id: string, callback: (surface: Surface) => void, _params?: SurfaceOptions): void;
    /**
     * Adds a miniview to the surface with the given id. For internal use.
     * @param surfaceId
     * @param params
     * @internal
     */
    addMiniview(surfaceId: string, params: MiniviewPluginOptions): void;
    /**
     * Store an arbitrary value on the service.
     * @param key
     * @param value
     * @public
     */
    store<T>(key: string, value: T): void;
    /**
     * Retrieve an arbitrary value from the service.
     * @param key
     * @public
     */
    retrieve<T>(key: string): T;
    /**
     * Register a shape library. A convenience method that creates a shape library and stores it
     * @param shapeSets the Shapes sets to register
     * @param key Key to register the shape library with. If you omit this, the default id will be used. If you call this
     * method multiple times without providing a `key`, the service will just overwrite what you previously stored.
     * @public
     */
    registerShapeLibrary<T extends ObjectData>(shapeSets: Array<ShapeSet>, key?: string): void;
    /**
     * Retrieve a shape library. A convenience method that prefixes the given key and then calls `retrieve`.
     * @param key Key used to register the shape library. If omitted, the default shape library key will be used.
     * @public
     */
    retrieveShapeLibrary<T extends ObjectData>(key?: string): ShapeLibraryImpl<T>;
    /**
     * Export an SVG from some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    exportSvg<T extends ObjectData>(options: AngularSvgExportOptions<T>): import("@jsplumbtoolkit/browser-ui").SvgExportOutput | {
        width: number;
        height: number;
        svg: string;
        dataUrl: string;
        viewBoxOnlySvg: string;
    };
    /**
     * Show the export SVG UI for some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    showSvgExportUI<T extends ObjectData>(options: AngularSvgExportUIOptions<T>): void | {
        width: number;
        height: number;
        svg: string;
        dataUrl: string;
        viewBoxOnlySvg: string;
    };
    /**
     * Export an image from some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    exportImage<T extends ObjectData>(options: AngularImageExportOptions<T>, onready: ImageReadyFunction): void;
    /**
     * Show the image export UI for some Surface, using either the ShapeLibrary registered on the surface, or one registered on the jsPlumb Angular service.
     * @param options
     */
    showImageExportUI<T extends ObjectData>(options: AngularImageExportUIOptions<T>): void;
    exportPNG<T extends ObjectData>(options: AngularImageExportOptions<T>, onready: ImageReadyFunction): void;
    exportJPG<T extends ObjectData>(options: AngularImageExportOptions<T>, onready: ImageReadyFunction): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<jsPlumbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<jsPlumbService>;
}
