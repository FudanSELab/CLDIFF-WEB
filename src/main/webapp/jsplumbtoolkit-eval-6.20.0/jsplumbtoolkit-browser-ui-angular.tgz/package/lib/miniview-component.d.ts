import { ElementRef } from "@angular/core";
import { jsPlumbService } from "./jsplumbtoolkit-service";
import { Group, Node } from "@jsplumbtoolkit/browser-ui";
import * as i0 from "@angular/core";
/**
 * A component that provides a miniview.
 * @public
 */
export declare class jsPlumbMiniviewComponent {
    private el;
    private $jsplumb;
    /**
     * ID of the surface to attach the miniview to. Required.
     * @public
     */
    surfaceId: string;
    /**
     * Optional filter to determine whether or not include a given vertex in the miniview
     * @public
     */
    elementFilter?: (obj: Node | Group) => boolean;
    /**
     * Optional function to determine a `type` for each vertex, which is then written as an attribute onto the DOM element
     * representing the vertex in the miniview.
     * @public
     */
    typeFunction?: (obj: Node | Group) => string;
    /**
     * Whether or not to move miniview elements at the same time as their related surface element is being dragged. Defaults to true.
     */
    activeTracking?: boolean;
    /**
     * Defaults to true, meaning a click on a node/group in the miniview will cause that node/group to be centered in the related surface.
     */
    clickToCenter?: boolean;
    constructor(el: ElementRef, $jsplumb: jsPlumbService);
    /**
     * @internal
     */
    ngAfterViewInit(): void;
    /**
     * @internal
     */
    redraw(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<jsPlumbMiniviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<jsPlumbMiniviewComponent, "jsplumb-miniview", never, { "surfaceId": "surfaceId"; "elementFilter": "elementFilter"; "typeFunction": "typeFunction"; "activeTracking": "activeTracking"; "clickToCenter": "clickToCenter"; }, {}, never, never>;
}
