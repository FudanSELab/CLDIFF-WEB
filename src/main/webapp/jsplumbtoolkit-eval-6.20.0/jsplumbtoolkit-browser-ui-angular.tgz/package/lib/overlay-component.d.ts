import { Edge, JsPlumbToolkit, ObjectData, Surface } from "@jsplumbtoolkit/browser-ui";
/**
 * Defines the type for an overlay that is represented by an angular component. Use this value in your views instead of
 * "Arrow", "Label" etc.
 * @public
 */
export declare const AngularComponentOverlayType = "AngularComponent";
/**
 * Defines an angular component that will act as an overlay. This interface exists largely for convenience; the code
 * will write the members of this interface onto any component it creates
 * @public
 */
export interface AngularOverlayComponent {
    toolkit: JsPlumbToolkit;
    surface: Surface;
    obj: ObjectData;
    edge: Edge;
}
/**
 * A base implementation of AngularOverlayComponent that you can use if its convenient for you. This class offers
 * an `updateEdge` and a `removeEdge` method, as helpers.
 * @public
 */
export declare abstract class BaseAngularOverlayComponent implements AngularOverlayComponent {
    toolkit: JsPlumbToolkit;
    surface: Surface;
    obj: ObjectData;
    edge: Edge;
    updateEdge(updates: ObjectData): void;
    removeEdge(): void;
}
