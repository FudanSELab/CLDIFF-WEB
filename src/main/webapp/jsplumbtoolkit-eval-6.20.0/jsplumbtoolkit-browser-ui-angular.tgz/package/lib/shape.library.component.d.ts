import { AfterViewInit, ElementRef, OnChanges, SimpleChanges } from "@angular/core";
import { ObjectData } from "@jsplumbtoolkit/browser-ui";
import { jsPlumbService } from "./jsplumbtoolkit-service";
import * as i0 from "@angular/core";
/**
 * Provides a means to render an SVG shape into a component.
 * @public
 */
export declare class ShapeLibraryComponent implements AfterViewInit, OnChanges {
    private $jsplumb;
    private ref;
    /**
     * The ID of the shape library to use. If not specified, a default will be used, which suffices for applications that
     * are only using one shape library.
     */
    shapeLibraryId: string;
    /**
     * The data for the vertex to render. Required.
     */
    obj: ObjectData;
    /**
     * Current width for the shape. Although it may seem counterintuitive, this is required - you'll need to set it to `[width]="obj.width"`.
     * Angular's change detection will not pick up changes to this otherwise.
     */
    width: number;
    /**
     * Current height. See notes for `width`.
     */
    height: number;
    /**
     * Whether or not to show labels.
     */
    showLabels: boolean;
    /**
     * Defaults to `label`. The name of the property inside each vertex that contains its label.
     */
    labelProperty?: string;
    /**
     * The stroke width to use for labels. Optional. Defaults to the Toolkit's default.
     */
    labelStrokeWidth?: string;
    private shapeLibrary;
    constructor($jsplumb: jsPlumbService, ref: ElementRef);
    private _render;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShapeLibraryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShapeLibraryComponent, "jtk-shape", never, { "shapeLibraryId": "shapeLibraryId"; "obj": "obj"; "width": "width"; "height": "height"; "showLabels": "showLabels"; "labelProperty": "labelProperty"; "labelStrokeWidth": "labelStrokeWidth"; }, {}, never, never>;
}
