import { AfterViewInit, ElementRef } from "@angular/core";
import { jsPlumbService } from "./jsplumbtoolkit-service";
import { ObjectData, Size, DataGeneratorFunction } from "@jsplumbtoolkit/browser-ui";
import * as i0 from "@angular/core";
export declare class ShapeLibraryPaletteComponent implements AfterViewInit {
    private $jsplumb;
    private el;
    /**
     * The ID of the shape library to render. Required.
     */
    shapeLibraryId: string;
    /**
     * The ID of the surface to attach to. Required.
     */
    surfaceId: string;
    /**
     * When the shape library contains multiple sets, use this to instruct the palette that you want it to initially load just
     * displaying this set.
     */
    initialSet: string;
    /**
     * Optional size to use for dragged elements.
     */
    dragSize: Size;
    /**
     * Optional size to use for icons.
     */
    iconSize: Size;
    /**
     * Optional fill color to use for dragged elements. This should be in RGB format, _not_ a color like 'white' or 'cyan' etc.
     */
    fill: string;
    /**
     * Optional color to use for outline of dragged elements. Should be in RGB format.
     */
    outline: string;
    /**
     * Message to use for the 'show all' option in the shape set drop down when there is more than one set of shapes.
     * Defaults to `Show all`.
     */
    showAllMessage: string;
    /**
     * When true (which is the default), a newly dropped vertex will be set as the underlying Toolkit's selection.
     */
    selectAfterDrop: boolean;
    /**
     * Stroke width to use in shapes on the canvas. Defaults to 2.
     */
    canvasStrokeWidth: number;
    /**
     * Stroke width to use in shapes in the palette. Defaults to 1.
     */
    paletteStrokeWidth?: number;
    /**
     * Optional function you can use to set some initial data for an element being dragged. Note that you cannot
     * override the object's `type` with this function.
     */
    dataGenerator: DataGeneratorFunction<ObjectData>;
    private shapeLibrary;
    constructor($jsplumb: jsPlumbService, el: ElementRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShapeLibraryPaletteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShapeLibraryPaletteComponent, "jtk-shape-palette", never, { "shapeLibraryId": "shapeLibraryId"; "surfaceId": "surfaceId"; "initialSet": "initialSet"; "dragSize": "dragSize"; "iconSize": "iconSize"; "fill": "fill"; "outline": "outline"; "showAllMessage": "showAllMessage"; "selectAfterDrop": "selectAfterDrop"; "canvasStrokeWidth": "canvasStrokeWidth"; "paletteStrokeWidth": "paletteStrokeWidth"; "dataGenerator": "dataGenerator"; }, {}, never, never>;
}
