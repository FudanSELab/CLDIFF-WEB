import { ComponentFactoryResolver, ComponentRef, ElementRef, EventEmitter, ViewContainerRef } from "@angular/core";
import { JsPlumbToolkitOptions, PortUpdatedParams, Vertex, VertexUpdatedParams, Surface } from "@jsplumbtoolkit/browser-ui";
import { BrowserUIAngular, jsPlumbService } from "./jsplumbtoolkit-service";
import { AngularRenderOptions, AngularViewOptions } from "./common";
import { AngularOverlayComponent } from "./overlay-component";
import * as i0 from "@angular/core";
/**
 * Provides a component that manages a surface.
 */
export declare class jsPlumbSurfaceComponent<VO extends AngularViewOptions = AngularViewOptions, RO extends AngularRenderOptions = AngularRenderOptions> {
    private el;
    private $jsplumb;
    private componentFactoryResolver;
    private viewContainerRef;
    /**
     * ID of the Toolkit to which to attach the surface. Required.
     */
    toolkitId: string;
    /**
     * ID to use for the created surface. Required.
     */
    surfaceId: string;
    /**
     * Options for the view - mappings of components and behaviour to model object types.
     */
    view: VO;
    /**
     * Options for the underlying surface widget.
     */
    renderParams: RO;
    /**
     * Optional parameters for the underlying Toolkit. These will be used only if the Toolkit instance with the given ID
     * has not yet been created somewhere else in the app.
     */
    toolkitParams?: JsPlumbToolkitOptions;
    /**
     * output event emitter, for proxying events from vertex components.
     */
    vertexEvent: EventEmitter<{
        vertex: Vertex;
        event: string;
        payload: any;
        component: ComponentRef<any>;
    }>;
    /**
     * @public
     */
    toolkit: BrowserUIAngular;
    /**
     * @public
     */
    surface: Surface;
    nodeUpdateFn: (a: any, e?: any) => any;
    groupUpdateFn: (a: any, e?: any) => any;
    portAddedFn: (a: any, e?: any) => any;
    portUpdateFn: (a: any, e?: any) => any;
    edgeUpdateFn: (a: any, e?: any) => any;
    edgeAddFn: (a: any, e?: any) => any;
    /**
     * map of overlays keyed by Connection id (NOT edge id). these are overlays that were added to connections as they were being
     * dragged, and so they didnt have an associated edge.
     * @internal
     */
    _uninitialisedOverlays: Map<string, Array<{
        componentRef: AngularOverlayComponent;
        createdComponent: ComponentRef<any>;
    }>>;
    /**
     * @internal
     * @param connectionId
     * @param component
     * @param el
     */
    private _addUninitializedOverlay;
    constructor(el: ElementRef, $jsplumb: jsPlumbService, componentFactoryResolver: ComponentFactoryResolver, viewContainerRef: ViewContainerRef);
    /**
     * abstract out the difference in accessing nativeElement between angular 2 (first case) and angular 4/5 (second case)
     * @param component
     * @internal
     */
    getNativeElement(component: any): any;
    /**
     * on node/group update, store the new data in the view
     * @internal
     */
    nodeOrGroupUpdated(params: VertexUpdatedParams): void;
    portUpdated(params: PortUpdatedParams): void;
    /**
     * When an edge updated event is received, check for angular overlays, and if they have a change detector,
     * invoke it. Used with OnPush change detection.
     * @internal
     * @param params
     */
    private edgeUpdated;
    /**
     * This method is invoked when a connection is established in the UI (not in the model), meaning it has just been
     * dragged. If there were any angular overlays on the edge they will not have been initialised properly, due to there
     * not being an edge prior to the finalisation of the connection. This method sets the `edge` and `obj` values on
     * the overlay, and then invokes its change detector, if set.
     * @param p
     * @internal
     */
    private _edgeAdded;
    /**
    * @internal
    */
    ngOnInit(): void;
    /**
     *
     * @param view
     * @internal
     */
    private _processAngularOverlays;
    /**
     * @internal
     */
    ngAfterViewInit(): void;
    /**
     * @internal
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<jsPlumbSurfaceComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<jsPlumbSurfaceComponent<any, any>, "jsplumb-surface", never, { "toolkitId": "toolkitId"; "surfaceId": "surfaceId"; "view": "view"; "renderParams": "renderParams"; "toolkitParams": "toolkitParams"; }, { "vertexEvent": "vertexEvent"; }, never, never>;
}
