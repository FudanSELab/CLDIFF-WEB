/**
 * This directive provides a means for you to configure the ability to drag/drop nodes and groups from some part of your UI
 * into the canvas.
 * @public
 */
import { DataGeneratorFunction, GroupIdentifierFunction, SurfaceDropManager, TypeGeneratorFunction } from "@jsplumbtoolkit/browser-ui";
import { ElementRef } from "@angular/core";
import { jsPlumbService } from "./jsplumbtoolkit-service";
import * as i0 from "@angular/core";
export declare class jsPlumbSurfaceDropComponent<T> {
    private el;
    private $jsplumb;
    constructor(el: ElementRef, $jsplumb: jsPlumbService);
    /**
     * CSS3 selector identifying the child elements of the the element on which this directive was declared that
     * act as drag sources.
     * @public
     */
    selector: string;
    /**
     * ID of the surface to attach to.
     * @public
     */
    surfaceId: string;
    /**
     * Function to use to generate an initial payload when the user starts to drag something from this component. Optional,
     * but you should almost certainly consider providing this, or a `typeGenerator`, since without one of these it is
     * not possible to determine the type of object beind dragged.
     * @public
     */
    dataGenerator: DataGeneratorFunction<T>;
    /**
     * Optional function to use to determine the type of object that a user has just started dragging
     * @public
     */
    typeGenerator: TypeGeneratorFunction<T>;
    /**
     * Optional function to use to determine if the object that is being dragged represents a group. If this function is present, and
     * returns true, then the drag object is considered to be a group. In all other cases the drag object is considered to
     * be a node.
     * @public
     */
    groupIdentifier: GroupIdentifierFunction<T>;
    /**
     * Optional extra selector to use when dragging to identify parts of the surface's canvas that should be considered
     * whitespace. If you use a decorator, for instance, or have otherwise positioned elements on your canvas, these elements
     * will not by default be considered whitespace.
     * @public
     */
    canvasSelector: string;
    /**
     * @internal
     */
    dropManager: SurfaceDropManager<T>;
    /**
     * Defaults to true. Allows items to be dropped onto edges in the canvas.
     */
    allowDropOnEdge: string;
    /**
     * Defaults to true. Allows items to be dropped onto groups in the canvas.
     */
    allowDropOnGroup: string;
    /**
     * Defaults to true. Allows items to be dropped onto whitespace.
     */
    allowDropOnCanvas: string;
    /**
     * Defaults to false. Allows items to be dropped onto nodes in the canvas. If this is true and an element is dropped onto a node, the
     * result is the same as if the element has been dropped onto whitespace.
     */
    allowDropOnNode: string;
    /**
     * @internal
     */
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<jsPlumbSurfaceDropComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<jsPlumbSurfaceDropComponent<any>, "[jsplumb-surface-drop]", never, { "selector": "selector"; "surfaceId": "surfaceId"; "dataGenerator": "dataGenerator"; "typeGenerator": "typeGenerator"; "groupIdentifier": "groupIdentifier"; "canvasSelector": "canvasSelector"; "allowDropOnEdge": "allowDropOnEdge"; "allowDropOnGroup": "allowDropOnGroup"; "allowDropOnCanvas": "allowDropOnCanvas"; "allowDropOnNode": "allowDropOnNode"; }, {}, never>;
}
