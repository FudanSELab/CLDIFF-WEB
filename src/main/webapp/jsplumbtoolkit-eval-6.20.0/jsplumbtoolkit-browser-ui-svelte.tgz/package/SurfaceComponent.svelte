
<script>

    import { onMount } from "svelte"
    import { newInstance} from "./index";
    import { render, uuid, log } from "@jsplumbtoolkit/browser-ui";

    /**
     * Render parameters for the Surface.
     */
    export let renderParams;

    /**
     * View parameters for the Surface.
     */
    export let viewParams;

    /**
     * Parameters for the underlying Toolkit instance.
     */
    export let toolkitParams;

    /**
     * Optional Toolkit to use. If this is not provided, a Toolkit instance will be created.
     */
    export let toolkit;

    /**
     * optional id for when you need to retrieve the renderer from the Toolkit. Internally we use this for testing;
     * there is probably no good reason for you to need to set this.
     */
    export let id;


    let surface
    let container;
    const componentMap = new Map();
    id = id || uuid()
    const elementId = `jtk_${id}`

    /**
     * Optional function that is used to generate a set of props for a given vertex before rendering it. This provides
     * a mechanism for you to inject specific items into the components you use to render your vertices.
     * The return value of this function should be `Record<string, any>`. It may be null.
     */
    export let injector;

    /**
     * Gets the underlying Surface widget
     * @return {*}
     */
    export function getSurface() { return surface }

    /**
     * Gets the underlying Toolkit
     * @return {*}
     */
    export function getToolkit() { return toolkit }

    onMount( async() => {

        toolkit = toolkit || newInstance(toolkitParams || {})
        container = document.querySelector(`[data-id='${elementId}']`)

        const templateRenderer = {
            asynchronous:false,
            reactive:false,
            update:(el, data, vertex, renderer) => {
                const component = componentMap.get(vertex.id)
                if (component) {
                    component.$set({data:vertex.data})
                }

            },
            render:(id, data, toolkit, type, surface, def, modelObject, node, eventInfo) => {

                if (def.component) {

                    let target = document.createElement("div");
                    let props = {
                        data: modelObject.data,
                        toolkit,
                        surface,
                        componentId: modelObject.getFullId(),
                        vertex: modelObject,
                        element: target,
                        eventInfo
                    };

                    // add any extra props supplied by the injector
                    if (injector != null) {
                        const injectedProps = injector(modelObject)
                        if (injectedProps != null) {
                            for (let key in injectedProps) {
                                props[key] = injectedProps[key]
                            }
                        }
                    }

                    const component = new def.component({props, target})
                    target._jsPlumbComponent = component

                    componentMap.set(modelObject.id, component)

                    surface.vertexRendered(modelObject, target, def, eventInfo)
                } else {
                    log("WARN: `component` not set for node/group - falling back to default template renderer with template " + id + ". Consider mapping a Svelte component in your view.") ;
                }

            },
            cleanupVertex:(objId, el) => {

                if (componentMap.has(objId)) {
                    componentMap.get(objId).$destroy()
                    componentMap.delete(objId)
                }

                el.parentNode && el.parentNode.removeChild(el)
            },
            cleanupPort:(objId, el) => {

            }
        }

        const params = renderParams || {}
        params.view = viewParams || {}
        params.id = id

        surface = render(toolkit, container, templateRenderer, params)

    })

</script>

<div data-id={elementId}></div>
