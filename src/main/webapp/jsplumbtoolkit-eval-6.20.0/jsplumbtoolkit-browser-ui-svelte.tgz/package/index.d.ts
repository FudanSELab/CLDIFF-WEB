///<reference types="svelte" />

import {JsPlumbToolkit, JsPlumbToolkitOptions, Vertex, BrowserUIBase, Surface, SurfaceRenderOptions, SurfaceViewOptions} from "@jsplumbtoolkit/browser-ui"
import { Writable } from "svelte/store"
import { SvelteComponent } from 'svelte'

/**
 * Extension of the Toolkit suitable for use with the Svelte integration.
 */
export declare class BrowserUISvelte extends BrowserUIBase {
    /**
     * @private
     * @param container
     * @param options
     */
    render(container: Element, options?: SurfaceRenderOptions): Surface;
}

/**
 * A simple wrapper around a store whose contents are expected to be in the Toolkit's JSON data format. When the store
 * posts an update event, the contents of the store are queried and the Toolkit's list of nodes, groups and edges
 * are updated to be in line with the contents of the store.
 */
export declare class StoreAdapter {
    constructor(toolkit:BrowserUISvelte, store:Writable<any>)
}

/**
 * Svelte wrapper around the Toolkit's Surface component.
 */
export declare class SurfaceComponent extends SvelteComponent {

    $$prop_def: {
        /**
         * Render parameters for the Surface.
         */
        renderParams?:SurfaceRenderOptions,

        /**
         * View parameters for the Surface.
         */
        viewParams?:SurfaceViewOptions,

        /**
         * Parameters for the underlying Toolkit instance.
         */
        toolkitParams?:JsPlumbToolkitOptions,

        /**
         * Optional Toolkit to use. If this is not provided, a Toolkit instance will be created.
         */
        toolkit?:JsPlumbToolkit

        /**
         * Optional function that is used to generate a set of props for a given vertex before rendering it. This provides
         * a mechanism for you to inject specific items into the components you use to render your vertices.
         * The return value of this function should be `Record<string, any>`. It may be null.
         */
        injector?:(v:Vertex) => Record<string, any>
    }

    /**
     * Gets the underlying Surface widget
     * @return {*}
     */
    getSurface():Surface

    /**
     * Gets the underlying Toolkit
     * @return {*}
     */
    getToolkit():BrowserUISvelte


}
