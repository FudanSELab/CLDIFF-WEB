/**
 * Provides integration with Svelte 3. This package has a dependency on @jsplumbtoolkit/browser-ui.
 *
 * For a detailed discussion of this package, see https://docs.jsplumbtoolkit.com/toolkit/6.x/lib/svelte-integration.
 *
 * @packageDocumentation
 */
export * from './components'
export * from './store-adapter'

import {BrowserUIBase, log} from "@jsplumbtoolkit/browser-ui"

/**
 * Extension of the Toolkit suitable for use with the Svelte integration.
 * @internal
 */
export class BrowserUISvelte extends BrowserUIBase {
    render(container, options) {
        log("render called directly on BrowserUISvelte class: should not happen. Surface component should use internal render.")
        return null
    }
}

/**
 * Creates a new instance of the Toolkit for use with the Svelte integration.
 * @param options
 * @internal
 */
export function newInstance(options) {
    options = options || {};
    return new BrowserUISvelte(options)
}
