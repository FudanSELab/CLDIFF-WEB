/**
 * A simple wrapper around a store whose contents are expected to be in the Toolkit's JSON data format. When the store
 * posts an update event, the contents of the store are queried and the Toolkit's list of nodes, groups and edges
 * are updated to be in line with the contents of the store.
 * @public
 */
export class StoreAdapter {

    constructor(toolkit, store) {
        this.toolkit = toolkit
        this.store = store

        store.subscribe(value => {
            this.processGroups(value.groups || [])
            this.processNodes(value.nodes || [])
            this.processEdges(value.edges || [])
        })
    }

    processNodes(nodes) {
        const toolkitNodes = this.toolkit.getNodes()
        const newNodes = nodes.filter(n => this.toolkit.getNode(n.id) == null)
        const removedNodes = toolkitNodes.filter(n => {
            return nodes.find(_n => _n.id === n.id) == null
        })

        removedNodes.forEach(n => this.toolkit.removeNode(n))
        newNodes.forEach(n => this.toolkit.addNode(n))
    }

    processGroups(groups) {
        const toolkitGroups = this.toolkit.getGroups()
        const newGroups = groups.filter(n => this.toolkit.getGroup(n.id) == null)
        const removedGroups = toolkitGroups.filter(n => {
            return groups.find(_n => _n.id === n.id) == null
        })

        removedGroups.forEach(n => this.toolkit.removeGroup(n))
        newGroups.forEach(n => this.toolkit.addGroup(n))
    }

    processEdges(edges) {
        const toolkitEdges = this.toolkit.getAllEdges()
        const newEdges = edges.filter(e => {
            e.data = e.data || {}
            let edgeId = e.data.id
            return edgeId == null || this.toolkit.getEdge(edgeId) == null
        })
        const removedEdges= toolkitEdges.filter(n => {
            return edges.find(_n => _n.id === n.id) == null
        })

        removedEdges.forEach(n => this.toolkit.removeEdge(n))
        newEdges.forEach(n => {
            const e = this.toolkit.addEdge(n)
            n.data.id = e.id
        })
    }
}
