import { JsPlumbToolkitOptions, Surface, BrowserUIBase, SurfaceRenderOptions } from "@jsplumbtoolkit/browser-ui";
/**
 * @internal
 */
export declare class BrowserUIVue2 extends BrowserUIBase {
    render(container: Element, options?: SurfaceRenderOptions): Surface;
}
/**
 * @internal
 * @param options
 */
export declare function newInstance(options?: JsPlumbToolkitOptions): BrowserUIVue2;
