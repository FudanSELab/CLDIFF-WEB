/**
 * Provides integration with Vue 2. This package has a dependency on @jsplumbtoolkit/browser-ui.
 *
 * For a detailed discussion of this package, see https://docs.jsplumbtoolkit.com/toolkit/6.x/lib/vue2-integration.
 *
 * @packageDocumentation
 */
export * from './browser-ui-vue2';
export * from './jsplumbtoolkit-browser-ui-vue2';
export * from './jsplumbtoolkit-browser-ui-vue2-drop';
export * from './shape-library-plugin';
export * from './inspector-plugin';
