export declare const TAG_EDGE_TYPE_PICKER = "jsplumb-edge-type-picker";
export declare const InspectorPlugin: {
    install: (vue: any, options: any) => void;
};
