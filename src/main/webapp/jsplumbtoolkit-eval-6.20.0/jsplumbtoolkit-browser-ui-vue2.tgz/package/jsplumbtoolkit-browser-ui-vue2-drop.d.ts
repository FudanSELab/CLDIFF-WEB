/**
 * Component to assist in adding drag/drop of new nodes/groups. This uses the low level DragManager under the hood - for most
 * applications you probably want the SurfaceDrop component instead.
 * @public
 */
export declare const DragDrop: {
    props: string[];
    mounted: () => void;
};
/**
 * Component to assist in adding drag/drop of new nodes/groups. This uses the SurfaceDropManager under the hood - for most
 * applications this will be sufficient. If you need finer-grained control, check out the DragDrop component.
 * @public
 */
export declare const SurfaceDrop: {
    props: string[];
    mounted: () => void;
};
