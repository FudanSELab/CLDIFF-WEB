import Vue from 'vue';
import { Surface, SurfaceViewOptions, SurfaceRenderOptions, MiniviewPluginOptions } from '@jsplumbtoolkit/browser-ui';
import { BrowserUIVue2 } from "./browser-ui-vue2";
/**
 * @public
 */
export interface Vue2RenderOptions extends Pick<SurfaceRenderOptions, Exclude<keyof SurfaceRenderOptions, ["view", "tags", "container", "directRender", "storePositionsInModel"]>> {
}
/**
 * @internal
 * @param id
 * @param toolkitParams
 */
export declare function addToolkit(id: string, toolkitParams?: any): BrowserUIVue2;
/**
 * Creates and registers a surface, injecting a template renderer that renders vertices as Vue components.
 * @internal
 * @param toolkitComponent
 * @param toolkit
 * @param surfaceId
 * @param container
 * @param renderParams
 * @param view
 */
export declare function addSurface(toolkitComponent: Vue, toolkit: BrowserUIVue2, surfaceId: string, container: any, renderParams?: Vue2RenderOptions, view?: SurfaceViewOptions): Surface;
/**
 * Register an externally created Surface with the Toolkit's Vue subsystem. This method lets you register a Surface that
 * you created using vanilla JS (for instance if you dont want to render using Vue components) and then other Vue components
 * such as a Palette or Inspector will be able to interact with it.
 * @param surfaceId
 * @param surface
 * @public
 */
export declare function registerSurface(surfaceId: string, surface: Surface): void;
/**
 * @internal
 * @param surfaceId
 * @param callback
 */
export declare function getSurface(surfaceId: string, callback: (s: Surface) => any): void;
/**
 * Add a component to the Surface with the given id. If the Surface already exists and has been initialised the component
 * will be added immediately; otherwise it will be enqueued for later processing.
 * @param surfaceId ID of the Surface to add the component to.
 * @param params Constructor parameters for the component.
 * @param type Type of component to add.
 * @internal
 */
export declare function addComponent(surfaceId: string, params: any, type: string): void;
/**
 * Add a Palette to the Surface with the given id. If the Surface already exists and has been initialised the Palette
 * will be added immediately; otherwise it will be enqueued for later processing. This method is not typically something
 * a user of the Toolkit will need to call, as the Palette component does this internally. But if you find that you want
 * to register a palette programmatically after your UI has been initialized, this method is what you need.
 * @param surfaceId ID of the Surface to add the Palette to.
 * @param params Constructor parameters for the Palette.
 * @public
 */
export declare function addPalette(surfaceId: string, params?: any): void;
/**
 * Add a Miniview to the Surface with the given id. If the Surface already exists and has been initialised the Miniview
 * will be added immediately; otherwise it will be enqueued for later processing. This method is not typically something
 * a user of the Toolkit will need to call, as the Miniview component does this internally. But if you find that you want
 * to register a miniview programmatically after your UI has been initialized, this method is what you need.
 * @param surfaceId ID of the Surface to add the Miniview to.
 * @param params Constructor parameters for the Miniview.
 * @public
 */
export declare function addMiniview(surfaceId: string, params?: MiniviewPluginOptions): void;
/**
 * Provides a mixin you can use to create a component that controls a set of droppable nodes for a Surface. See documentation for usage details.
 * @param surfaceId ID of the Surface to configure the palette to drop to.
 * @public
 */
export declare const Palette: {
    props: string[];
    mounted: () => void;
};
/**
 * Provides a mixin you should use to create a component that renders a node. See documentation for usage details.
 * @public
 */
export declare const BaseNodeComponent: {
    methods: {
        getNode: () => any;
        getToolkit: () => any;
        removeNode: () => void;
        updateNode: (data: any) => void;
    };
};
/**
 * Provides a mixin you should use to create a component that renders a group. See documentation for usage details.
 * @public
 */
export declare const BaseGroupComponent: {
    methods: {
        getGroup: () => any;
        getToolkit: () => any;
        removeGroup: (removeChildNodes?: boolean) => void;
        updateGroup: (data: any) => void;
    };
};
/**
 * The Toolkit's Vue2 integration plugin. See documentation for usage details.
 * @public
 */
export declare const JsPlumbToolkitVue2Plugin: {
    install: (vue: any, options: any) => void;
};
