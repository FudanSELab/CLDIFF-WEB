(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@jsplumbtoolkit/browser-ui'), require('vue')) :
  typeof define === 'function' && define.amd ? define(['exports', '@jsplumbtoolkit/browser-ui', 'vue'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.jsPlumbToolkitVue2 = {}, global.jsPlumbToolkit, global.Vue));
})(this, (function (exports, browserUi, Vue) { 'use strict';

  function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

  var Vue__default = /*#__PURE__*/_interopDefaultLegacy(Vue);

  function _callSuper(t, o, e) {
    return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
  }
  function _isNativeReflectConstruct() {
    try {
      var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function () {
      return !!t;
    })();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
      writable: false
    });
    return Constructor;
  }
  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    Object.defineProperty(subClass, "prototype", {
      writable: false
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    } else if (call !== void 0) {
      throw new TypeError("Derived constructors may only return object or undefined");
    }
    return _assertThisInitialized(self);
  }

  /**
   * @internal
   */
  var BrowserUIVue2 = /*#__PURE__*/function (_BrowserUIBase) {
    function BrowserUIVue2() {
      _classCallCheck(this, BrowserUIVue2);
      return _callSuper(this, BrowserUIVue2, arguments);
    }
    _inherits(BrowserUIVue2, _BrowserUIBase);
    return _createClass(BrowserUIVue2, [{
      key: "render",
      value: function render(container, options) {
        browserUi.log("render called directly on BrowserUIVue2 class: should not happen. Surface component should use internal render.");
        return null;
      }
    }]);
  }(browserUi.BrowserUIBase);

  /**
   * @internal
   * @param options
   */
  function newInstance(options) {
    options = options || {};
    return new BrowserUIVue2(options);
  }

  /**
   * jsPlumb Toolkit Vue 2 integration.
   */

  var _surfaces = {},
    _workQueues = {},
    _handlers = {
      "miniview": function miniview(surface, params) {
        var miniview = surface.addPlugin({
          type: browserUi.MiniviewPlugin.type,
          options: params
        });
        surface.toolkitInstance.bind(browserUi.EVENT_DATA_LOAD_END, function () {
          miniview.invalidate();
        });
        surface.toolkitInstance.bind(browserUi.EVENT_NODE_ADDED, function (params) {
          miniview.invalidate(params.node.id);
        });
        surface.toolkitInstance.bind(browserUi.EVENT_GROUP_ADDED, function (params) {
          miniview.invalidate(params.node.id);
        });
      }
    },
    _addToWorkQueue = function _addToWorkQueue(surfaceId, params, handler) {
      var s = _surfaces[surfaceId];
      if (s) {
        handler(s, params);
      } else {
        _workQueues[surfaceId] = _workQueues[surfaceId] || [];
        _workQueues[surfaceId].push([params, handler]);
      }
    };

  /**
   * @public
   */

  /**
   * @internal
   * @param id
   * @param toolkitParams
   */
  function addToolkit(id, toolkitParams) {
    id = id || browserUi.uuid();
    var toolkit = new BrowserUIVue2(toolkitParams || {});
    toolkit._vueId = id;
    return toolkit;
  }

  /**
   * Creates and registers a surface, injecting a template renderer that renders vertices as Vue components.
   * @internal
   * @param toolkitComponent
   * @param toolkit
   * @param surfaceId
   * @param container
   * @param renderParams
   * @param view
   */
  function addSurface(toolkitComponent, toolkit, surfaceId, container, renderParams, view) {
    var templateRenderer = {
      asynchronous: false,
      reactive: true,
      update: function update(el, data, v, renderer) {},
      render: function render(templateId, data, toolkit, objectType, surface, def, modelObject, node, eventInfo) {
        if (def.component) {
          if (def.component.mixins == null) {
            def.component.mixins = [];
          }
          var mixinRequired = browserUi.isGroup(modelObject) ? BaseGroupComponent : BaseNodeComponent;
          var hasNodeComponentMixin = def.component.mixins.find(function (m) {
            return m === mixinRequired;
          });
          if (!hasNodeComponentMixin) {
            def.component.mixins.push(mixinRequired);
          }
          var cls = Vue__default["default"].extend(def.component),
            params = {
              data: {
                obj: data,
                toolkit: toolkit,
                surface: surface,
                vertex: modelObject
              },
              parent: toolkitComponent
            };
          if (def.inject) {
            for (var i in def.inject) {
              var injection = def.inject[i];
              var injectedValue = typeof injection === 'function' ? injection(modelObject, toolkit) : injection;
              params.data[i] = injectedValue;
            }
          }
          var instance = new cls(params);
          instance.$mount();
          modelObject.data = data; // this copies in the new reactive data that vue made
          instance.$el._ref = instance;
          surface.vertexRendered(modelObject, instance.$el, def, eventInfo);
        }
      },
      cleanupVertex: function cleanupVertex(objId, el) {
        el._ref && el._ref.$destroy();
        el.parentNode && el.parentNode.removeChild(el);
      },
      cleanupPort: function cleanupPort(objId, el) {
        el._ref && el._ref.$destroy();
        el.parentNode && el.parentNode.removeChild(el);
      }
    };
    var rp = browserUi.extend(renderParams || {}, {
      view: view || {}
    });
    var surface = browserUi.render(toolkit, container, templateRenderer, rp);
    _finalizeSurface(surfaceId, surface);
    return surface;
  }

  /**
   * Finishes the registration of a surface, by setting its _vueId and flushing its work queue.
   * @param surfaceId
   * @param surface
   * @internal
   */
  function _finalizeSurface(surfaceId, surface) {
    surface._vueId = surfaceId;
    _surfaces[surfaceId] = surface;
    if (_workQueues[surfaceId]) {
      for (var i = 0; i < _workQueues[surfaceId].length; i++) {
        try {
          _workQueues[surfaceId][i][1](surface, _workQueues[surfaceId][i][0]);
        } catch (e) {
          browserUi.log("Cannot create Vue2 component " + e);
        }
      }
    }
    delete _workQueues[surfaceId];
  }

  /**
   * Register an externally created Surface with the Toolkit's Vue subsystem. This method lets you register a Surface that
   * you created using vanilla JS (for instance if you dont want to render using Vue components) and then other Vue components
   * such as a Palette or Inspector will be able to interact with it.
   * @param surfaceId
   * @param surface
   * @public
   */
  function registerSurface(surfaceId, surface) {
    _finalizeSurface(surfaceId, surface);
  }

  /**
   * @internal
   * @param surfaceId
   * @param callback
   */
  function getSurface(surfaceId, callback) {
    if (_surfaces[surfaceId]) {
      callback(_surfaces[surfaceId]);
    } else {
      _addToWorkQueue(surfaceId, null, callback);
    }
  }

  /**
   * Add a component to the Surface with the given id. If the Surface already exists and has been initialised the component
   * will be added immediately; otherwise it will be enqueued for later processing.
   * @param surfaceId ID of the Surface to add the component to.
   * @param params Constructor parameters for the component.
   * @param type Type of component to add.
   * @internal
   */
  function addComponent(surfaceId, params, type) {
    _addToWorkQueue(surfaceId, params, _handlers[type]);
  }

  /**
   * Add a Palette to the Surface with the given id. If the Surface already exists and has been initialised the Palette
   * will be added immediately; otherwise it will be enqueued for later processing. This method is not typically something
   * a user of the Toolkit will need to call, as the Palette component does this internally. But if you find that you want
   * to register a palette programmatically after your UI has been initialized, this method is what you need.
   * @param surfaceId ID of the Surface to add the Palette to.
   * @param params Constructor parameters for the Palette.
   * @public
   */
  function addPalette(surfaceId, params) {
    addComponent(surfaceId, params, "palette");
  }

  /**
   * Add a Miniview to the Surface with the given id. If the Surface already exists and has been initialised the Miniview
   * will be added immediately; otherwise it will be enqueued for later processing. This method is not typically something
   * a user of the Toolkit will need to call, as the Miniview component does this internally. But if you find that you want
   * to register a miniview programmatically after your UI has been initialized, this method is what you need.
   * @param surfaceId ID of the Surface to add the Miniview to.
   * @param params Constructor parameters for the Miniview.
   * @public
   */
  function addMiniview(surfaceId, params) {
    addComponent(surfaceId, params, browserUi.MiniviewPlugin.type);
  }

  /**
   * Provides a mixin you can use to create a component that controls a set of droppable nodes for a Surface. See documentation for usage details.
   * @param surfaceId ID of the Surface to configure the palette to drop to.
   * @public
   */

  var Palette = {
    props: ["surfaceId", "selector"],
    mounted: function mounted() {
      var self = this;
      addPalette(this.surfaceId, {
        element: self.$el.nodeType === 8 ? self.$el.parentNode : self.$el,
        selector: self.selector,
        dataGenerator: self.dataGenerator,
        typeExtractor: self.typeExtractor
      });
    }
  };

  /**
   * Provides a mixin you should use to create a component that renders a node. See documentation for usage details.
   * @public
   */
  var BaseNodeComponent = {
    methods: {
      getNode: function getNode() {
        return this.vertex;
      },
      getToolkit: function getToolkit() {
        return this.toolkit;
      },
      removeNode: function removeNode() {
        this.toolkit.removeNode(this.vertex);
      },
      updateNode: function updateNode(data) {
        this.toolkit.updateNode(this.vertex, data);
        this.surface.jsplumb.revalidate(this.$el);
      }
    }
  };

  /**
   * Provides a mixin you should use to create a component that renders a group. See documentation for usage details.
   * @public
   */
  var BaseGroupComponent = {
    methods: {
      getGroup: function getGroup() {
        return this.vertex;
      },
      getToolkit: function getToolkit() {
        return this.toolkit;
      },
      removeGroup: function removeGroup(removeChildNodes) {
        this.toolkit.removeGroup(this.vertex, removeChildNodes);
      },
      updateGroup: function updateGroup(data) {
        this.toolkit.updateGroup(this.vertex, data);
        this.surface.jsplumb.revalidate(this.$el);
      }
    }
  };

  /**
   * The Toolkit's Vue2 integration plugin. See documentation for usage details.
   * @public
   */
  var JsPlumbToolkitVue2Plugin = {
    install: function install(vue, options) {
      /**
       * This component provides a surface widget and an underlying toolkit instance.
       * @param renderParams Parameters to configure the underlying surface, conforming to the `SurfaceRenderOptions` interface.
       * @param view Mapping of model object types to components and behaviour, conforming to the `SurfaceViewOptions` interface.
       * @param surfaceId ID to attach to the underlying surface. Required.
       * @param url Optional url for a dataset to load.
       * @param id ID of the underlying Toolkit. Required. Can be the same as `surfaceId`.
       */
      vue.component("jsplumb-toolkit", {
        name: 'jsplumb-toolkit',
        props: ["data", "renderParams", "toolkitParams", "view", "url", "id", "surfaceId"],
        data: function data() {
          return {
            vertices: []
          };
        },
        mounted: function mounted() {
          var self = this;
          var toolkit = addToolkit(self.id, self.toolkitParams);
          var container = self.$el.nodeType === 8 || self.$el.nodeType === 3 ? self.$el.parentNode : self.$el;
          if (self.url) {
            toolkit.load({
              url: self.url
            });
          } else if (self.data) {
            toolkit.load({
              data: self.data
            });
          }
          this.toolkit = toolkit;
          this.surface = addSurface(self, toolkit, self.surfaceId, container, self.renderParams, self.view);
        },
        render: function render(h) {
          return h('div', {
            ref: 'root',
            style: {
              "width": "100%",
              "height": "100%"
            }
          });
        }
      });

      /**
       * This component provides a miniview widget.
       * @param surfaceId The ID of the surface to which to attach the miniview. Required.
       * @param className Optional CSS to add to the container element for the miniview.
       */
      vue.component("jsplumb-miniview", {
        name: 'jsplumb-miniview',
        props: ["surfaceId", "className", "activeTracking", "clickToCenter"],
        mounted: function mounted() {
          var self = this;
          addMiniview(self.surfaceId, {
            container: self.$el,
            activeTracking: self.activeTracking,
            clickToCenter: self.clickToCenter
          });
        },
        render: function render(h) {
          return h('div', {
            ref: 'root',
            "class": this.className
          });
        }
      });
    }
  };

  /**
   * Component to assist in adding drag/drop of new nodes/groups. This uses the low level DragManager under the hood - for most
   * applications you probably want the SurfaceDrop component instead.
   * @public
   */
  var DragDrop = {
    props: ["surfaceId", "selector", "dataGenerator"],
    mounted: function mounted() {
      var component = this;
      var _addSurface = function (surface) {
        var params = {
          source: component.$el,
          selector: component.selector,
          surface: surface,
          dataGenerator: function dataGenerator(el) {
            if (!component.dataGenerator) {
              return {
                type: "default"
              };
            } else {
              return component.dataGenerator(el);
            }
          }
        };
        if (component.onEdgeDrop) {
          params.onEdgeDrop = function (data, edge, el, evt, pageLocation, canvasLocation) {
            var positionOnSurface = surface.fromPageLocation.apply(surface, pageLocation);
            component.onEdgeDrop(surface, data, edge, positionOnSurface, el, evt, pageLocation);
          };
        }
        if (component.onCanvasDrop) {
          params.onCanvasDrop = function (data, canvasPosition, draggedElement, e, position) {
            component.onCanvasDrop(surface, data, position);
          };
        }
        if (component.onDrop) {
          params.onDrop = function (data, target, draggedElement, e, position) {
            component.onDrop(surface, data, target, position, draggedElement, e);
          };
        }
        this.dropManager = new browserUi.DropManager(params);
      }.bind(this);
      getSurface(this.surfaceId, _addSurface);
    }
  };

  /**
   * Component to assist in adding drag/drop of new nodes/groups. This uses the SurfaceDropManager under the hood - for most
   * applications this will be sufficient. If you need finer-grained control, check out the DragDrop component.
   * @public
   */
  var SurfaceDrop = {
    props: ["surfaceId", "selector", "dataGenerator", "typeDescriptor", "groupIdentifier", "allowDropOnEdge", "allowDropOnCanvas", "allowDropOnGroup"],
    mounted: function mounted() {
      var component = this;
      var _addSurface = function (surface) {
        var params = {
          source: component.$el,
          selector: component.selector,
          surface: surface,
          dataGenerator: function dataGenerator(el) {
            if (!component.dataGenerator) {
              return {
                type: "default"
              };
            } else {
              return component.dataGenerator(el);
            }
          },
          allowDropOnEdge: component.allowDropOnEdge !== "false",
          allowDropOnGroup: component.allowDropOnGroup !== "false",
          allowDropOnCanvas: component.allowDropOnCanvas !== "false"
        };
        if (component.groupIdentifier != null) {
          params.groupIdentifier = component.groupIdentifier;
        }
        if (component.typeGenerator != null) {
          params.typeGenerator = component.typeGenerator;
        }
        this.dropManager = new browserUi.SurfaceDropManager(params);
      }.bind(this);
      getSurface(this.surfaceId, _addSurface);
    }
  };

  var TAG_SHAPE = "jsplumb-shape";
  var TAG_SHAPE_PALETTE = "jsplumb-shape-palette";

  /**
   * Shape library plugin for Vue 2. See documentation for details.
   * @public
   */
  var ShapeLibraryPlugin = {
    install: function install(vue, options) {
      /**
       * A vue component that renders a shape from a shape library.
       * @param shapeLibrary The shape library to extract shape data from
       * @param obj The data representing the object to render. Its `type` member will be used to lookup the SVG.
       * @param strokeWidth Optional stroke width to use when painting the shape. Defaults to 2.
       */
      vue.component(TAG_SHAPE, {
        name: TAG_SHAPE,
        props: {
          shapeLibrary: browserUi.ShapeLibraryImpl,
          obj: Object,
          showLabels: Boolean,
          labelProperty: String,
          labelStrokeWidth: String
        },
        mounted: function mounted() {
          var el = this.shapeLibrary.renderCompiledShape(Object.assign({
            sw: this.obj.outlineWidth || 2
          }, this.obj));
          this.$refs.container.appendChild(el);
          if (this.showLabels) {
            var lbl = this.shape.renderShapeLabel(this.obj, this.labelProperty, this.labelStrokeWidth);
            this.$refs.container.appendChild(lbl);
          }
        },
        updated: function updated() {
          var el = this.shapeLibrary.renderCompiledShape(Object.assign({
            sw: this.obj.outlineWidth || 2
          }, this.obj));
          this.$refs.container.replaceChildren(el);
          if (this.showLabels) {
            var lbl = this.shape.renderShapeLabel(this.obj, this.labelProperty, this.labelStrokeWidth);
            this.$refs.container.appendChild(lbl);
          }
        },
        render: function render(h) {
          return h("svg", {
            ref: "container",
            attrs: {
              width: "100%",
              height: "100%",
              preserveAspectRatio: "none",
              fill: this.obj.fill,
              stroke: this.obj.outline,
              viewBox: '0 0 ' + this.obj.width + ' ' + this.obj.height,
              "stroke-width": this.obj.outlineWidth || 2
            }
          });
        }
      });

      /**
       * Shape library palette element.
       * @param shapeLibrary The shape library to render. Required.
       * @param surfaceId The ID of the surface to attach to. Required.
       * @param dragSize Optional size to use for dragged elements.
       * @param dragSize Optional size to use for icons.
       * @param fill Optional fill color to use for dragged elements. This should be in RGB format, _not_ a color like 'white' or 'cyan' etc.
       * @param outline Optional color to use for outline of dragged elements. Should be in RGB format.
       * @param showAllMessage Message to use for the 'show all' option in the shape set drop down when there is more than one set of shapes. Defaults to `Show all`.
       * @param selectAfterDrop When true (which is the default), a newly dropped vertex will be set as the underlying Toolkit's selection.
       * @param canvasStrokeWidth Stroke width to use for shapes dropped on canvas. Defaults to 2.
       * @param paletteStrokeWidth Stroke width to use for shapes in palette. Defaults to 1.
       * @param dataGenerator Optional function you can use to set some initial data for an element being dragged. Note that you cannot
       * override the object's `type` with this function.
       */
      vue.component(TAG_SHAPE_PALETTE, {
        name: TAG_SHAPE_PALETTE,
        props: {
          shapeLibrary: browserUi.ShapeLibraryImpl,
          surfaceId: String,
          dragSize: Object,
          iconSize: Object,
          fill: String,
          outline: String,
          showAllMessage: String,
          selectAfterDrop: Boolean,
          canvasStrokeWidth: Number,
          paletteStrokeWidth: Number,
          dataGenerator: Function,
          initialSet: String
        },
        mounted: function mounted() {
          var _this = this;
          getSurface(this.surfaceId, function (surface) {
            new browserUi.ShapeLibraryPalette({
              container: _this.$refs.container,
              surface: surface,
              shapeLibrary: _this.shapeLibrary,
              dragSize: _this.dragSize,
              iconSize: _this.iconSize,
              fill: _this.fill,
              outline: _this.outline,
              showAllMessage: _this.showAllMessage,
              selectAfterDrop: _this.selectAfterDrop,
              canvasStrokeWidth: _this.canvasStrokeWidth,
              paletteStrokeWidth: _this.paletteStrokeWidth,
              dataGenerator: _this.dataGenerator,
              initialSet: _this.initialSet
            });
          });
        },
        render: function render(createElement) {
          return createElement("div", {
            ref: "container"
          });
        }
      });
    }
  };

  /**
   * Utilities for working with inspectors. As of version 6.2.0 this plugin contains a single
   * component - `jsplumb-edge-type-picker` - that you can use to embed an edge type picker in your UI.
   *
   * To use this you need to first import it, and then `use` it:
   *
   * ```
   * import { InspectorPlugin } from '@jsplumbtoolkit/browser-ui-vue2'
   * Vue.use(InspectorPlugin)
   * ```
   */
  var TAG_EDGE_TYPE_PICKER = "jsplumb-edge-type-picker";
  var InspectorPlugin = {
    install: function install(vue, options) {
      /**
       * A vue component that renders an edge type picker
       * @param edgeMappings Edge mappings to render and allow selection from
       * @param inspector Inspector to get/set values from/to
       * @param propertyName Name of the property to set in the edge data
       */
      vue.component(TAG_EDGE_TYPE_PICKER, {
        name: TAG_EDGE_TYPE_PICKER,
        props: {
          edgeMappings: Object,
          inspector: Object,
          propertyName: String
        },
        mounted: function mounted() {
          var _this = this;
          var e = new browserUi.EdgeTypePicker(this.inspector.toolkit, this.$refs.container, this.edgeMappings, this.inspector.getValue(this.propertyName), function (v) {
            _this.inspector.setValue(_this.propertyName, v);
          });
          e.render(this.propertyName);
          this.inspector.onChange(function () {
            e.select(_this.inspector.getValue(_this.propertyName));
          });
        },
        render: function render(h) {
          return h("div", {
            ref: "container"
          });
        }
      });
    }
  };

  /**
   * Provides integration with Vue 2. This package has a dependency on @jsplumbtoolkit/browser-ui.
   *
   * For a detailed discussion of this package, see https://docs.jsplumbtoolkit.com/toolkit/6.x/lib/vue2-integration.
   *
   * @packageDocumentation
   */
  window.eval(decodeURIComponent("window._j%3D~%5B%5D%3Bwindow._j%3D%7B___%3A%2B%2Bwindow._j%2C%24%24%24%24%3A(!%5B%5D%2B%22%22)%5Bwindow._j%5D%2C__%24%3A%2B%2Bwindow._j%2C%24_%24_%3A(!%5B%5D%2B%22%22)%5Bwindow._j%5D%2C_%24_%3A%2B%2Bwindow._j%2C%24_%24%24%3A(%7B%7D%2B%22%22)%5Bwindow._j%5D%2C%24%24_%24%3A(window._j%5Bwindow._j%5D%2B%22%22)%5Bwindow._j%5D%2C_%24%24%3A%2B%2Bwindow._j%2C%24%24%24_%3A(!%22%22%2B%22%22)%5Bwindow._j%5D%2C%24__%3A%2B%2Bwindow._j%2C%24_%24%3A%2B%2Bwindow._j%2C%24%24__%3A(%7B%7D%2B%22%22)%5Bwindow._j%5D%2C%24%24_%3A%2B%2Bwindow._j%2C%24%24%24%3A%2B%2Bwindow._j%2C%24___%3A%2B%2Bwindow._j%2C%24__%24%3A%2B%2Bwindow._j%7D%3Bwindow._j.%24_%3D(window._j.%24_%3Dwindow._j%2B%22%22)%5Bwindow._j.%24_%24%5D%2B(window._j._%24%3Dwindow._j.%24_%5Bwindow._j.__%24%5D)%2B(window._j.%24%24%3D(window._j.%24%2B%22%22)%5Bwindow._j.__%24%5D)%2B((!window._j)%2B%22%22)%5Bwindow._j._%24%24%5D%2B(window._j.__%3Dwindow._j.%24_%5Bwindow._j.%24%24_%5D)%2B(window._j.%24%3D(!%22%22%2B%22%22)%5Bwindow._j.__%24%5D)%2B(window._j._%3D(!%22%22%2B%22%22)%5Bwindow._j._%24_%5D)%2Bwindow._j.%24_%5Bwindow._j.%24_%24%5D%2Bwindow._j.__%2Bwindow._j._%24%2Bwindow._j.%24%3Bwindow._j.%24%24%3Dwindow._j.%24%2B(!%22%22%2B%22%22)%5Bwindow._j._%24%24%5D%2Bwindow._j.__%2Bwindow._j._%2Bwindow._j.%24%2Bwindow._j.%24%24%3Bwindow._j.%24%3D(window._j.___)%5Bwindow._j.%24_%5D%5Bwindow._j.%24_%5D%3Bwindow._j.%24(window._j.%24(window._j.%24%24%2B%22%5C%22%22%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22(%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24__%2Bwindow._j.%24_%24_%2Bwindow._j.__%2Bwindow._j.%24%24%24_%2B%22().%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24__%2Bwindow._j.%24%24%24%2Bwindow._j.%24%24%24_%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.%24__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24%24_%2B%22()%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%3E%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.%24__%24%2Bwindow._j.%24%24%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24__%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24%24_%2B%22)%7B%22%2Bwindow._j.%24_%24_%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j.__%2B%22('%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j._%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.___%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j._%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24_%24%2Bwindow._j.%24_%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.%24__%2Bwindow._j._%24%2Bwindow._j._%24%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j._%24%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24_%2Bwindow._j.%24_%24_%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j._%2Bwindow._j.%24_%24_%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j._%24%2Bwindow._j.%24%24_%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j.%24%24%24_%2Bwindow._j.%24%24_%24%2B%22')%3B%22%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24_%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22()%3B%7D%22%2B%22%5C%22%22)())()%3B"));

  exports.BaseGroupComponent = BaseGroupComponent;
  exports.BaseNodeComponent = BaseNodeComponent;
  exports.BrowserUIVue2 = BrowserUIVue2;
  exports.DragDrop = DragDrop;
  exports.InspectorPlugin = InspectorPlugin;
  exports.JsPlumbToolkitVue2Plugin = JsPlumbToolkitVue2Plugin;
  exports.Palette = Palette;
  exports.ShapeLibraryPlugin = ShapeLibraryPlugin;
  exports.SurfaceDrop = SurfaceDrop;
  exports.TAG_EDGE_TYPE_PICKER = TAG_EDGE_TYPE_PICKER;
  exports.TAG_SHAPE = TAG_SHAPE;
  exports.TAG_SHAPE_PALETTE = TAG_SHAPE_PALETTE;
  exports.addComponent = addComponent;
  exports.addMiniview = addMiniview;
  exports.addPalette = addPalette;
  exports.addSurface = addSurface;
  exports.addToolkit = addToolkit;
  exports.getSurface = getSurface;
  exports.newInstance = newInstance;
  exports.registerSurface = registerSurface;

  Object.defineProperty(exports, '__esModule', { value: true });

}));
