export declare const TAG_SHAPE = "jsplumb-shape";
export declare const TAG_SHAPE_PALETTE = "jsplumb-shape-palette";
/**
 * Shape library plugin for Vue 2. See documentation for details.
 * @public
 */
export declare const ShapeLibraryPlugin: {
    install: (vue: any, options: any) => void;
};
