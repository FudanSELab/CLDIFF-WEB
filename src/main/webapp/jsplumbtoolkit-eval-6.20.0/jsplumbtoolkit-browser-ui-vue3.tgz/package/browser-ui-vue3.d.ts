import { JsPlumbToolkitOptions, Surface, BrowserUIBase, SurfaceRenderOptions } from "@jsplumbtoolkit/browser-ui";
/**
 * Toolkit instance for use with Vue3 integration.
 * @internal
 */
export declare class BrowserUIVue3 extends BrowserUIBase {
    render(container: Element, options?: SurfaceRenderOptions): Surface;
}
/**
 * Create a new instance of the Toolkit to use with the Vue 3 integration.
 * @param options - Options for the Toolkit instance.
 * @internal
 */
export declare function newInstance(options?: JsPlumbToolkitOptions): BrowserUIVue3;
