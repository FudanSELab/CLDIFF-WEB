export declare const TAG_EDGE_TYPE_PICKER = "jsplumb-edge-type-picker";
/**
 * Utilities for working with inspectors. This plugin contains a single
 * component - `jsplumb-edge-type-picker` - that you can use to embed an edge type picker in your UI.
 * @public
 */
export declare const InspectorPlugin: {
    install: (vue: any, options: any) => void;
};
