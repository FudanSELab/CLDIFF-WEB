import { MiniviewPluginOptions, Vertex, Surface, SurfaceViewOptions, SurfaceRenderOptions } from '@jsplumbtoolkit/browser-ui';
import { BrowserUIVue3 } from "./browser-ui-vue3";
export interface Vue3RenderOptions extends Pick<SurfaceRenderOptions, Exclude<keyof SurfaceRenderOptions, ["view", "tags", "container", "directRender", "storePositionsInModel"]>> {
}
/**
 * @internal
 * @param id
 * @param toolkitParams
 */
export declare function addToolkit(id: string, toolkitParams?: any): BrowserUIVue3;
/**
 * @internal
 * @param toolkitComponent
 * @param toolkit
 * @param surfaceId
 * @param container
 * @param vertices
 * @param renderParams
 * @param view
 */
export declare function addSurface(toolkitComponent: any, toolkit: BrowserUIVue3, surfaceId: string, container: any, vertices: Array<any>, renderParams?: Vue3RenderOptions, view?: SurfaceViewOptions): Surface;
/**
 * Register an externally created Surface with the Toolkit's Vue subsystem. This method lets you register a Surface that
 * you created using vanilla JS (for instance if you dont want to render using Vue components) and then other Vue components
 * such as a Palette or Inspector will be able to interact with it.
 * @param surfaceId
 * @param surface
 * @public
 */
export declare function registerSurface(surfaceId: string, surface: Surface): void;
/**
 * Loads the Surface with the given ID.
 * @param surfaceId - ID of the Surface to retrieve
 * @param callback - Callback function to hit once the Surface has been retrieved.
 * @public
 */
export declare function loadSurface(surfaceId: string, callback: (s: Surface) => any): void;
/**
 * Add a component to the Surface with the given id. If the Surface already exists and has been initialised the component
 * will be added immediately; otherwise it will be enqueued for later processing. This is for internal use.
 * @param surfaceId - ID of the Surface to add the component to.
 * @param params - Constructor parameters for the component.
 * @param type - Type of component to add.
 * @internal
 */
export declare function addComponent(surfaceId: string, params: any, type: string): void;
/**
 * Add a Palette to the Surface with the given id. If the Surface already exists and has been initialised the Palette
 * will be added immediately; otherwise it will be enqueued for later processing. This is really just a wrapper around
 * addComponent, and is for internal use also.
 * @param surfaceId - ID of the Surface to add the Palette to.
 * @param params - Constructor parameters for the Palette.
 * @internal
 */
export declare function addPalette(surfaceId: string, params?: any): void;
/**
 * Add a Miniview to the Surface with the given id. If the Surface already exists and has been initialised the Miniview
 * will be added immediately; otherwise it will be enqueued for later processing. This is just a wrapper around addComponent.
 * @param surfaceId - ID of the Surface to add the Miniview to.
 * @param params - Constructor parameters for the Miniview.
 * @internal
 */
export declare function addMiniview(surfaceId: string, params?: MiniviewPluginOptions): void;
/**
 * Provides a mixin you can use to create a component that controls a set of droppable nodes for a Surface. See documentation for details.
 * @param surfaceId - ID of the Surface to configure the palette to drop to.
 * @param selector - CSS 3 selector identifying draggable child elements.
 * @public
 */
export declare const Palette: {
    props: {
        surfaceId: StringConstructor;
        selector: StringConstructor;
    };
    mounted: () => void;
};
export declare const EVENT_VERTICES_RENDERED = "vertices:rendered";
export declare const EVENT_VERTEX_UPDATED = "vertex:updated";
export declare function bindToDevLifecycle(event: string, handler: (a: any, e?: any) => any): void;
/**
 * Provides a mixin you should use to create a component that renders a node. See documentation for details.
 * @public
 */
export declare const BaseNodeComponent: {
    mixins: {
        props: {
            obj: ObjectConstructor;
            toolkit: typeof BrowserUIVue3;
            vertex: typeof Vertex;
            surface: typeof Surface;
            el: {
                new (): Element;
                prototype: Element;
            };
            def: ObjectConstructor;
            eventInfo: ObjectConstructor;
        };
        mounted(): void;
        methods: {
            /**
             * get the underlying Toolkit instance.
             * @public
             */
            getToolkit: () => any;
            /**
             * Removed the vertex this component representes.
             * @public
             */
            removeVertex: () => void;
        };
        updated(): void;
    }[];
    methods: {
        getNode: () => any;
        removeNode: () => void;
        updateNode: (data: any) => void;
    };
};
/**
 * Provides a mixin you should use to create a component that renders a group. See documentation for details.
 * @public
 */
export declare const BaseGroupComponent: {
    methods: {
        /**
         * Gets the underlying group from the model.
         */
        getGroup: () => any;
        /**
         * Removes the group this component represents from the model.
         * @param removeChildNodes
         */
        removeGroup: (removeChildNodes?: boolean) => void;
        /**
         * Updates the underlying group in the model.
         * @param data
         */
        updateGroup: (data: any) => void;
    };
    mixins: {
        props: {
            obj: ObjectConstructor;
            toolkit: typeof BrowserUIVue3;
            vertex: typeof Vertex;
            surface: typeof Surface;
            el: {
                new (): Element;
                prototype: Element;
            };
            def: ObjectConstructor;
            eventInfo: ObjectConstructor;
        };
        mounted(): void;
        methods: {
            /**
             * get the underlying Toolkit instance.
             * @public
             */
            getToolkit: () => any;
            /**
             * Removed the vertex this component representes.
             * @public
             */
            removeVertex: () => void;
        };
        updated(): void;
    }[];
};
/**
 * The Toolkit's Vue3 integration plugin. See documentation for details.
 * @public
 */
export declare const JsPlumbToolkitVue3Plugin: {
    install: (vue: any, options: any) => void;
};
export declare const PROP_CLICK_TO_CENTER = "clickToCenter";
export declare const PROP_ACTIVE_TRACKING = "activeTracking";
export declare const PROP_SURFACE_ID = "surfaceId";
export declare const PROP_CLASS_NAME = "className";
export declare const PROP_DATA = "data";
export declare const PROP_RENDER_PARAMS = "renderParams";
export declare const PROP_TOOLKIT_PARAMS = "toolkitParams";
export declare const PROP_VIEW = "view";
export declare const PROP_URL = "url";
export declare const PROP_ID = "id";
export declare const COMPONENT_MINIVIEW = "jsplumb-miniview";
export declare const COMPONENT_TOOLKIT = "jsplumb-toolkit";
