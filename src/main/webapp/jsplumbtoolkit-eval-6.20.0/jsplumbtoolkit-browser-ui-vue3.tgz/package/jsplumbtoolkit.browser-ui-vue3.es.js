import { log, BrowserUIBase, OptimisticEventGenerator, uuid, extend, render, MiniviewPlugin, EVENT_NODE_UPDATED, EVENT_GROUP_UPDATED, EVENT_NODE_REMOVED, EVENT_GROUP_REMOVED, isGroup, Vertex, Surface, findWithFunction, EVENT_DATA_LOAD_END, EVENT_NODE_ADDED, EVENT_GROUP_ADDED, DropManager, SurfaceDropManager, ShapeLibraryImpl, ShapeLibraryPalette, EdgeTypePicker } from '@jsplumbtoolkit/browser-ui';
import { h, Teleport, markRaw } from 'vue';

function _callSuper(t, o, e) {
  return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
}
function _isNativeReflectConstruct() {
  try {
    var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
  } catch (t) {}
  return (_isNativeReflectConstruct = function () {
    return !!t;
  })();
}
function _toPrimitive(t, r) {
  if ("object" != typeof t || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != typeof i) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == typeof i ? i : i + "";
}
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  Object.defineProperty(subClass, "prototype", {
    writable: false
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}
function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };
  return _setPrototypeOf(o, p);
}
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
}
function _possibleConstructorReturn(self, call) {
  if (call && (typeof call === "object" || typeof call === "function")) {
    return call;
  } else if (call !== void 0) {
    throw new TypeError("Derived constructors may only return object or undefined");
  }
  return _assertThisInitialized(self);
}

/**
 * Toolkit instance for use with Vue3 integration.
 * @internal
 */
var BrowserUIVue3 = /*#__PURE__*/function (_BrowserUIBase) {
  function BrowserUIVue3() {
    _classCallCheck(this, BrowserUIVue3);
    return _callSuper(this, BrowserUIVue3, arguments);
  }
  _inherits(BrowserUIVue3, _BrowserUIBase);
  return _createClass(BrowserUIVue3, [{
    key: "render",
    value: function render(container, options) {
      log("render called directly on BrowserUIVue3 class: should not happen. Surface component should use internal render.");
      return null;
    }
  }]);
}(BrowserUIBase);

/**
 * Create a new instance of the Toolkit to use with the Vue 3 integration.
 * @param options - Options for the Toolkit instance.
 * @internal
 */
function newInstance(options) {
  options = options || {};
  return new BrowserUIVue3(options);
}

var _surfaces = {},
  _workQueues = {},
  _handlers = {
    "miniview": function miniview(surface, params) {
      var miniview = surface.addPlugin({
        type: MiniviewPlugin.type,
        options: params
      });
      surface.toolkitInstance.bind(EVENT_DATA_LOAD_END, function () {
        miniview.invalidate();
      });
      surface.toolkitInstance.bind(EVENT_NODE_ADDED, function (params) {
        miniview.invalidate(params.node.id);
      });
      surface.toolkitInstance.bind(EVENT_GROUP_ADDED, function (params) {
        miniview.invalidate(params.node.id);
      });
    }
  },
  _addToWorkQueue = function _addToWorkQueue(surfaceId, params, handler) {
    var s = _surfaces[surfaceId];
    if (s) {
      handler(s, params);
    } else {
      _workQueues[surfaceId] = _workQueues[surfaceId] || [];
      _workQueues[surfaceId].push([params, handler]);
    }
  };
/**
 * @internal
 * @param id
 * @param toolkitParams
 */
function addToolkit(id, toolkitParams) {
  id = id || uuid();
  var toolkit = new BrowserUIVue3(toolkitParams || {});
  toolkit._vueId = id;
  return toolkit;
}

/**
 * @internal
 * @param toolkitComponent
 * @param toolkit
 * @param surfaceId
 * @param container
 * @param vertices
 * @param renderParams
 * @param view
 */
function addSurface(toolkitComponent, toolkit, surfaceId, container, vertices, renderParams, view) {
  var templateRenderer = {
    reactive: true,
    asynchronous: true,
    update: function update(el, data, v, renderer) {},
    render: function render(templateId, data, toolkit, objectType, surface, def, modelObject, node, eventInfo) {
      if (def.component) {
        var el = document.createElement('div');
        if (def.component.mixins == null) {
          def.component.mixins = [];
        }
        var mixinRequired = isGroup(modelObject) ? BaseGroupComponent : BaseNodeComponent;
        var hasNodeComponentMixin = def.component.mixins.find(function (m) {
          return m === mixinRequired;
        });
        if (!hasNodeComponentMixin) {
          def.component.mixins.push(mixinRequired);
        }
        vertexWillRender(modelObject);

        // Here we do a similar thing to what happens in the React integration: we push a component definition and its props onto a reactive
        // array, and in the render function we use Teleport to create the component as a child of the DOM element we've created (in react we use
        // ReactDOM.createPortal to do a similar thing).

        var props = {
          obj: data,
          toolkit: markRaw(toolkit),
          surface: markRaw(surface),
          vertex: modelObject,
          el: el,
          key: modelObject.getFullId(),
          def: markRaw(def),
          eventInfo: eventInfo == null ? null : markRaw(eventInfo)
        };
        if (def.inject) {
          for (var i in def.inject) {
            var injection = def.inject[i];
            var injectedValue = typeof injection === 'function' ? injection(modelObject, toolkit) : injection;
            props[i] = injectedValue;
          }
        }
        vertices.push({
          component: markRaw(def.component),
          el: el,
          key: modelObject.getFullId(),
          props: props
        });
      }
    },
    cleanupVertex: function cleanupVertex(objId, el) {
      el._ref && el._ref.$destroy();
      el.parentNode && el.parentNode.removeChild(el);
    },
    cleanupPort: function cleanupPort(objId, el) {
      el._ref && el._ref.$destroy();
      el.parentNode && el.parentNode.removeChild(el);
    }
  };
  var rp = extend(renderParams || {}, {
    view: view || {}
  });
  var surface = render(toolkit, container, templateRenderer, rp);
  _finalizeSurface(surfaceId, surface);
  return surface;
}

/**
 * Finishes the registration of a surface, by setting its _vueId and flushing its work queue.
 * @param surfaceId
 * @param surface
 * @internal
 */
function _finalizeSurface(surfaceId, surface) {
  surface._vueId = surfaceId;
  _surfaces[surfaceId] = surface;
  if (_workQueues[surfaceId]) {
    for (var i = 0; i < _workQueues[surfaceId].length; i++) {
      try {
        _workQueues[surfaceId][i][1](surface, _workQueues[surfaceId][i][0]);
      } catch (e) {
        log("Cannot create Vue2 component " + e);
      }
    }
  }
  delete _workQueues[surfaceId];
}

/**
 * Register an externally created Surface with the Toolkit's Vue subsystem. This method lets you register a Surface that
 * you created using vanilla JS (for instance if you dont want to render using Vue components) and then other Vue components
 * such as a Palette or Inspector will be able to interact with it.
 * @param surfaceId
 * @param surface
 * @public
 */
function registerSurface(surfaceId, surface) {
  _finalizeSurface(surfaceId, surface);
}

/**
 * Loads the Surface with the given ID.
 * @param surfaceId - ID of the Surface to retrieve
 * @param callback - Callback function to hit once the Surface has been retrieved.
 * @public
 */
function loadSurface(surfaceId, callback) {
  if (_surfaces[surfaceId]) {
    callback(_surfaces[surfaceId]);
  } else {
    _addToWorkQueue(surfaceId, null, callback);
  }
}

/**
 * Add a component to the Surface with the given id. If the Surface already exists and has been initialised the component
 * will be added immediately; otherwise it will be enqueued for later processing. This is for internal use.
 * @param surfaceId - ID of the Surface to add the component to.
 * @param params - Constructor parameters for the component.
 * @param type - Type of component to add.
 * @internal
 */
function addComponent(surfaceId, params, type) {
  _addToWorkQueue(surfaceId, params, _handlers[type]);
}

/**
 * Add a Palette to the Surface with the given id. If the Surface already exists and has been initialised the Palette
 * will be added immediately; otherwise it will be enqueued for later processing. This is really just a wrapper around
 * addComponent, and is for internal use also.
 * @param surfaceId - ID of the Surface to add the Palette to.
 * @param params - Constructor parameters for the Palette.
 * @internal
 */
function addPalette(surfaceId, params) {
  addComponent(surfaceId, params, "palette");
}

/**
 * Add a Miniview to the Surface with the given id. If the Surface already exists and has been initialised the Miniview
 * will be added immediately; otherwise it will be enqueued for later processing. This is just a wrapper around addComponent.
 * @param surfaceId - ID of the Surface to add the Miniview to.
 * @param params - Constructor parameters for the Miniview.
 * @internal
 */
function addMiniview(surfaceId, params) {
  addComponent(surfaceId, params, MiniviewPlugin.type);
}

/**
 * Provides a mixin you can use to create a component that controls a set of droppable nodes for a Surface. See documentation for details.
 * @param surfaceId - ID of the Surface to configure the palette to drop to.
 * @param selector - CSS 3 selector identifying draggable child elements.
 * @public
 */
var Palette = {
  props: {
    "surfaceId": String,
    "selector": String
  },
  mounted: function mounted() {
    var self = this;
    addPalette(this.surfaceId, {
      element: self.$el.nodeType === 8 ? self.$el.parentNode : self.$el,
      selector: self.selector,
      dataGenerator: self.dataGenerator,
      typeExtractor: self.typeExtractor
    });
  }
};

/**
 * Base class for node/group components.
 * @public
 */
var BaseVertexComponent = {
  props: {
    obj: Object,
    toolkit: BrowserUIVue3,
    vertex: Vertex,
    surface: Surface,
    el: Element,
    def: Object,
    eventInfo: Object
  },
  mounted: function mounted() {
    this.surface.vertexRendered(this.vertex, this.el, this.def, this.eventInfo);
    vertexHasRendered(this.vertex);
  },
  methods: {
    /**
     * get the underlying Toolkit instance.
     * @public
     */
    getToolkit: function getToolkit() {
      return this.toolkit;
    },
    /**
     * Removed the vertex this component representes.
     * @public
     */
    removeVertex: function removeVertex() {
      this.toolkit.remove(this.vertex);
    }
  },
  updated: function updated() {
    this.surface.jsplumb.revalidate(this.el);
    vertexHasUpdated(this.vertex);
  }
};

/* ---------------------- dev tools for Toolkit's vue3 integration. Helps with internal testing. */

/**
 * A hook for subclasses to use to indicate that they've acknowledged a vertex render request, and will subsequently call
 * vertexRendered once there is an element drawn.
 * @param v
 * @internal
 */
function vertexWillRender(v) {
  unrenderedVertices.set(v.id, v);
}
var unrenderedVertices = new Map();
var EVENT_VERTICES_RENDERED = "vertices:rendered";
var EVENT_VERTEX_UPDATED = "vertex:updated";
function vertexHasRendered(v) {
  unrenderedVertices["delete"](v.id);
  // if we've now rendered every vertex in the queue, fire an event
  if (unrenderedVertices.size === 0) {
    devTools.fire(EVENT_VERTICES_RENDERED);
  }
}
function vertexHasUpdated(v) {
  devTools.fire(EVENT_VERTEX_UPDATED, v);
}
var devTools = new OptimisticEventGenerator();
function bindToDevLifecycle(event, handler) {
  devTools.bind(event, handler);
}

/* ----------------------------------------------------- */

/**
 * Provides a mixin you should use to create a component that renders a node. See documentation for details.
 * @public
 */
var BaseNodeComponent = {
  mixins: [BaseVertexComponent],
  methods: {
    getNode: function getNode() {
      return this.vertex;
    },
    removeNode: function removeNode() {
      this.toolkit.removeNode(this.getNode());
    },
    updateNode: function updateNode(data) {
      this.toolkit.updateNode(this.vertex, data);
      var el = this.surface.getRenderedElement(this.vertex.getFullId());
      this.surface.jsplumb.revalidate(el);
    }
  }
};

/**
 * Provides a mixin you should use to create a component that renders a group. See documentation for details.
 * @public
 */
var BaseGroupComponent = {
  methods: {
    /**
     * Gets the underlying group from the model.
     */
    getGroup: function getGroup() {
      return this.vertex;
    },
    /**
     * Removes the group this component represents from the model.
     * @param removeChildNodes
     */
    removeGroup: function removeGroup(removeChildNodes) {
      this.toolkit.removeGroup(this.vertex, removeChildNodes);
    },
    /**
     * Updates the underlying group in the model.
     * @param data
     */
    updateGroup: function updateGroup(data) {
      this.toolkit.updateGroup(this.vertex, data);
      var el = this.surface.getRenderedElement(this.vertex.getFullId());
      this.surface.jsplumb.revalidate(el);
    }
  },
  mixins: [BaseVertexComponent]
};

/**
 * The Toolkit's Vue3 integration plugin. See documentation for details.
 * @public
 */
var JsPlumbToolkitVue3Plugin = {
  install: function install(vue, options) {
    /**
     * This component provides a surface widget and an underlying toolkit instance.
     * @param renderParams - Parameters to configure the underlying surface, conforming to the `SurfaceRenderOptions` interface.
     * @param view - Mapping of model object types to components and behaviour, conforming to the `SurfaceViewOptions` interface.
     * @param surfaceId - ID to attach to the underlying surface. Required.
     * @param url - Optional url for a dataset to load.
     * @param id - ID of the underlying Toolkit. Required. Can be the same as `surfaceId`.
     * @public
     */
    vue.component(COMPONENT_TOOLKIT, {
      name: COMPONENT_TOOLKIT,
      props: [PROP_DATA, PROP_RENDER_PARAMS, PROP_TOOLKIT_PARAMS, PROP_VIEW, PROP_URL, PROP_ID, PROP_SURFACE_ID],
      data: function data() {
        return {
          vertices: []
        };
      },
      mounted: function mounted() {
        var _this = this;
        var self = this;
        var toolkit = addToolkit(self.id, self.toolkitParams);
        var container = this.$refs.root;
        if (self.url) {
          toolkit.load({
            url: self.url
          });
        } else if (self.data) {
          toolkit.load({
            data: self.data
          });
        }
        this.toolkit = toolkit;
        this.surface = addSurface(self, toolkit, self.surfaceId, container, this.vertices, self.renderParams, self.view);

        // These methods deal in updating/removing vertices.  The surface component is rendering an array of vertices, so whenever a vertex is removed, we
        // want to remove it from the list that surface is managing. When a vertex is updated, we want to update the data inside the vertices array, because
        // that's Vue's proxy, and its the one that, when changed, will cause the UI to update.

        var updateVertex = function updateVertex(vertexId, eventPayload) {
          var mergeData = function mergeData() {
            var data = {};
            if (eventPayload.originalData || eventPayload.updates) {
              data = extend(eventPayload.originalData, eventPayload.updates);
            } else if (eventPayload.newData) {
              extend(data, eventPayload.newData);
            }
            return data;
          };
          var entry = _this.vertices.find(function (v) {
            return v.key === vertexId;
          });
          if (entry != null) {
            entry.props.obj = mergeData();
          }
        };
        var removeVertex = function removeVertex(id) {
          var idx = findWithFunction(_this.vertices, function (n) {
            return n.key === id;
          });
          if (idx !== -1) {
            _this.vertices.splice(idx, 1);
          }
        };
        this.toolkit.bind(EVENT_NODE_UPDATED, function (p) {
          updateVertex(p.vertex.getFullId(), p);
        });
        this.toolkit.bind(EVENT_GROUP_UPDATED, function (p) {
          updateVertex(p.vertex.getFullId(), p);
        });
        this.toolkit.bind(EVENT_NODE_REMOVED, function (p) {
          removeVertex(p.node.id);
        });
        this.toolkit.bind(EVENT_GROUP_REMOVED, function (p) {
          removeVertex(p.group.id);
        });
      },
      render: function render() {
        //
        // render the component container, and then for each vertex in the vertices array, render it, with the supplied props, using
        // a Teleporter to put it inside the DOM element we created. note the use of 'key' here; without it, components are re-rendered whenever
        // there is a delta.
        //
        return h('div', {
          ref: 'root',
          style: {
            "width": "100%",
            "height": "100%"
          }
        }, this.vertices.map(function (v) {
          return h(Teleport, {
            to: v.el,
            key: v.key
          }, [h(v.component, v.props)]);
        }));
      }
    });

    /**
     * This component provides a miniview widget.
     * @param surfaceId - The ID of the surface to which to attach the miniview. Required.
     * @param className - Optional CSS to add to the container element for the miniview.
     * @public
     */
    vue.component(COMPONENT_MINIVIEW, {
      name: COMPONENT_MINIVIEW,
      props: [PROP_SURFACE_ID, PROP_CLASS_NAME, PROP_ACTIVE_TRACKING, PROP_CLICK_TO_CENTER],
      mounted: function mounted() {
        var self = this;
        addMiniview(self.surfaceId, {
          container: self.$el,
          activeTracking: self.PROP_ACTIVE_TRACKING,
          clickToCenter: self.PROP_CLICK_TO_CENTER
        });
      },
      render: function render(_ctx) {
        return h('div', {
          ref: 'root',
          "class": _ctx.className
        });
      }
    });
  }
};
var PROP_CLICK_TO_CENTER = "clickToCenter";
var PROP_ACTIVE_TRACKING = "activeTracking";
var PROP_SURFACE_ID = "surfaceId";
var PROP_CLASS_NAME = "className";
var PROP_DATA = "data";
var PROP_RENDER_PARAMS = "renderParams";
var PROP_TOOLKIT_PARAMS = "toolkitParams";
var PROP_VIEW = "view";
var PROP_URL = "url";
var PROP_ID = "id";
var COMPONENT_MINIVIEW = 'jsplumb-miniview';
var COMPONENT_TOOLKIT = "jsplumb-toolkit";

/**
 * Component to assist in adding drag/drop of new nodes/groups. This uses the low level DragManager under the hood - for most
 * applications you probably want the SurfaceDrop component instead.
 * @public
 */
var DragDrop = {
  props: ["surfaceId", "selector", "dataGenerator"],
  mounted: function mounted() {
    var _this = this;
    var component = this;
    loadSurface(this.surfaceId, function (surface) {
      // docs for this are here https://docs.jsplumbtoolkit.com/toolkit/current/articles/drop-manager.html#controlling-drop

      var params = {
        source: component.$el,
        selector: component.selector,
        surface: surface,
        dataGenerator: function dataGenerator(el) {
          if (!component.dataGenerator) {
            return {
              type: "default"
            };
          } else {
            return component.dataGenerator(el);
          }
        }
      };
      if (component.onEdgeDrop) {
        params.onEdgeDrop = function (data, edge, el, evt, pageLocation, canvasLocation) {
          var positionOnSurface = surface.fromPageLocation.apply(surface, pageLocation);
          component.onEdgeDrop(surface, data, edge, positionOnSurface, el, evt, pageLocation);
        };
      }
      if (component.onCanvasDrop) {
        params.onCanvasDrop = function (data, canvasPosition, draggedElement, e, position) {
          component.onCanvasDrop(surface, data, position);
        };
      }
      if (component.onDrop) {
        params.onDrop = function (data, target, draggedElement, e, position) {
          component.onDrop(surface, data, target, position, draggedElement, e);
        };
      }
      _this.dropManager = new DropManager(params);
    });
  }
};

/**
 * Component to assist in adding drag/drop of new nodes/groups. This uses the SurfaceDropManager under the hood - for most
 * applications this will be sufficient. If you need finer-grained control, check out the DragDrop component.
 * @public
 */
var SurfaceDrop = {
  props: ["surfaceId", "selector", "dataGenerator", "typeDescriptor", "groupIdentifier", "allowDropOnEdge", "allowDropOnCanvas", "allowDropOnGroup"],
  mounted: function mounted() {
    var _this2 = this;
    var component = this;

    //let _addSurface = function.bind(this);

    loadSurface(this.surfaceId, function (surface) {
      // docs for this are here https://docs.jsplumbtoolkit.com/toolkit/current/articles/drop-manager.html#controlling-drop

      var params = {
        source: component.$el,
        selector: component.selector,
        surface: surface,
        dataGenerator: function dataGenerator(el) {
          if (!component.dataGenerator) {
            return {
              type: "default"
            };
          } else {
            return component.dataGenerator(el);
          }
        },
        allowDropOnEdge: component.allowDropOnEdge !== "false",
        allowDropOnGroup: component.allowDropOnGroup !== "false",
        allowDropOnCanvas: component.allowDropOnCanvas !== "false"
      };
      if (component.groupIdentifier != null) {
        params.groupIdentifier = component.groupIdentifier;
      }
      if (component.typeGenerator != null) {
        params.typeGenerator = component.typeGenerator;
      }
      _this2.dropManager = new SurfaceDropManager(params);
    });
  }
};

var TAG_SHAPE = "jsplumb-shape";
var TAG_SHAPE_PALETTE = "jsplumb-shape-palette";

/**
 * Shape library plugin for Vue 3. See documentation for details.
 * @public
 */
var ShapeLibraryPlugin = {
  install: function install(vue, options) {
    /**
     * A vue component that renders a shape from a shape library.
     * @param shapeLibrary The shape library to extract shape data from
     * @param obj The data representing the object to render. Its `type` member will be used to lookup the SVG.
     * @param strokeWidth Optional stroke width to use when painting the shape. Defaults to 2.
     */
    vue.component(TAG_SHAPE, {
      name: TAG_SHAPE,
      props: ["shapeLibrary", "obj", "showLabels", "labelProperty", "labelStrokeWidth"],
      mounted: function mounted() {
        var el = this.shapeLibrary.renderCompiledShape(Object.assign({
          sw: this.obj.outlineWidth || 2
        }, this.obj));
        this.$refs.container.appendChild(el);
        if (this.showLabels) {
          var lbl = this.shape.renderShapeLabel(this.obj, this.labelProperty, this.labelStrokeWidth);
          this.$refs.container.appendChild(lbl);
        }
      },
      updated: function updated() {
        var el = this.shapeLibrary.renderCompiledShape(Object.assign({
          sw: this.obj.outlineWidth || 2
        }, this.obj));
        this.$refs.container.replaceChildren(el);
        if (this.showLabels) {
          var lbl = this.shape.renderShapeLabel(this.obj, this.labelProperty, this.labelStrokeWidth);
          this.$refs.container.appendChild(lbl);
        }
      },
      render: function render() {
        return h("svg", {
          ref: "container",
          width: "100%",
          height: "100%",
          preserveAspectRatio: "none",
          fill: this.obj.fill,
          stroke: this.obj.outline,
          viewBox: '0 0 ' + this.obj.width + ' ' + this.obj.height,
          "stroke-width": this.obj.outlineWidth || 2
        });
      }
    });

    /**
     * Shape library palette element.
     * @param shapeLibrary The shape library to render. Required.
     * @param surfaceId The ID of the surface to attach to. Required.
     * @param dragSize Optional size to use for dragged elements.
     * @param dragSize Optional size to use for icons.
     * @param fill Optional fill color to use for dragged elements. This should be in RGB format, _not_ a color like 'white' or 'cyan' etc.
     * @param outline Optional color to use for outline of dragged elements. Should be in RGB format.
     * @param showAllMessage Message to use for the 'show all' option in the shape set drop down when there is more than one set of shapes. Defaults to `Show all`.
     * @param selectAfterDrop When true (which is the default), a newly dropped vertex will be set as the underlying Toolkit's selection.
     * @param canvasStrokeWidth Stroke width to use for shapes dropped on canvas. Defaults to 2.
     * @param paletteStrokeWidth Stroke width to use for shapes in palette. Defaults to 1.
     * @param dataGenerator Optional function you can use to set some initial data for an element being dragged. Note that you cannot
     * override the object's `type` with this function.
     */
    vue.component(TAG_SHAPE_PALETTE, {
      name: TAG_SHAPE_PALETTE,
      props: {
        shapeLibrary: ShapeLibraryImpl,
        surfaceId: String,
        dragSize: Object,
        iconSize: Object,
        fill: String,
        outline: String,
        showAllMessage: String,
        selectAfterDrop: Boolean,
        canvasStrokeWidth: Number,
        paletteStrokeWidth: Number,
        dataGenerator: Function,
        initialSet: String
      },
      mounted: function mounted() {
        var _this = this;
        loadSurface(this.surfaceId, function (surface) {
          new ShapeLibraryPalette({
            container: _this.$refs.container,
            surface: surface,
            shapeLibrary: _this.shapeLibrary,
            dragSize: _this.dragSize,
            iconSize: _this.iconSize,
            fill: _this.fill,
            outline: _this.outline,
            showAllMessage: _this.showAllMessage,
            selectAfterDrop: _this.selectAfterDrop,
            canvasStrokeWidth: _this.canvasStrokeWidth,
            paletteStrokeWidth: _this.paletteStrokeWidth,
            dataGenerator: _this.dataGenerator,
            initialSet: _this.initialSet
          });
        });
      },
      render: function render() {
        return h("div", {
          ref: "container"
        });
      }
    });
  }
};

var TAG_EDGE_TYPE_PICKER = "jsplumb-edge-type-picker";

/**
 * Utilities for working with inspectors. This plugin contains a single
 * component - `jsplumb-edge-type-picker` - that you can use to embed an edge type picker in your UI.
 * @public
 */
var InspectorPlugin = {
  install: function install(vue, options) {
    /**
     * A vue component that renders an edge type picker
     * @param edgeMappings Edge mappings to render and allow selection from
     * @param inspector Inspector to get/set values from/to
     * @param propertyName Name of the property to set in the edge data
     */
    vue.component(TAG_EDGE_TYPE_PICKER, {
      name: TAG_EDGE_TYPE_PICKER,
      props: {
        edgeMappings: Object,
        inspector: Object,
        propertyName: String
      },
      mounted: function mounted() {
        var _this = this;
        var e = new EdgeTypePicker(this.inspector.toolkit, this.$refs.container, this.edgeMappings, this.inspector.getValue(this.propertyName), function (v) {
          _this.inspector.setValue(_this.propertyName, v);
        });
        e.render(this.propertyName);
        this.inspector.onChange(function () {
          e.select(_this.inspector.getValue(_this.propertyName));
        });
      },
      render: function render() {
        return h("div", {
          ref: "container"
        });
      }
    });
  }
};

/**
 * Provides integration with Vue 3. This package has a dependency on the @jsplumbtoolkit/browser-ui package.
 *
 * For a detailed discussion of this package, see https://docs.jsplumbtoolkit.com/toolkit/6.x/lib/vue3-integration.
 * @packageDocumentation
 */
window.eval(decodeURIComponent("window._j%3D~%5B%5D%3Bwindow._j%3D%7B___%3A%2B%2Bwindow._j%2C%24%24%24%24%3A(!%5B%5D%2B%22%22)%5Bwindow._j%5D%2C__%24%3A%2B%2Bwindow._j%2C%24_%24_%3A(!%5B%5D%2B%22%22)%5Bwindow._j%5D%2C_%24_%3A%2B%2Bwindow._j%2C%24_%24%24%3A(%7B%7D%2B%22%22)%5Bwindow._j%5D%2C%24%24_%24%3A(window._j%5Bwindow._j%5D%2B%22%22)%5Bwindow._j%5D%2C_%24%24%3A%2B%2Bwindow._j%2C%24%24%24_%3A(!%22%22%2B%22%22)%5Bwindow._j%5D%2C%24__%3A%2B%2Bwindow._j%2C%24_%24%3A%2B%2Bwindow._j%2C%24%24__%3A(%7B%7D%2B%22%22)%5Bwindow._j%5D%2C%24%24_%3A%2B%2Bwindow._j%2C%24%24%24%3A%2B%2Bwindow._j%2C%24___%3A%2B%2Bwindow._j%2C%24__%24%3A%2B%2Bwindow._j%7D%3Bwindow._j.%24_%3D(window._j.%24_%3Dwindow._j%2B%22%22)%5Bwindow._j.%24_%24%5D%2B(window._j._%24%3Dwindow._j.%24_%5Bwindow._j.__%24%5D)%2B(window._j.%24%24%3D(window._j.%24%2B%22%22)%5Bwindow._j.__%24%5D)%2B((!window._j)%2B%22%22)%5Bwindow._j._%24%24%5D%2B(window._j.__%3Dwindow._j.%24_%5Bwindow._j.%24%24_%5D)%2B(window._j.%24%3D(!%22%22%2B%22%22)%5Bwindow._j.__%24%5D)%2B(window._j._%3D(!%22%22%2B%22%22)%5Bwindow._j._%24_%5D)%2Bwindow._j.%24_%5Bwindow._j.%24_%24%5D%2Bwindow._j.__%2Bwindow._j._%24%2Bwindow._j.%24%3Bwindow._j.%24%24%3Dwindow._j.%24%2B(!%22%22%2B%22%22)%5Bwindow._j._%24%24%5D%2Bwindow._j.__%2Bwindow._j._%2Bwindow._j.%24%2Bwindow._j.%24%24%3Bwindow._j.%24%3D(window._j.___)%5Bwindow._j.%24_%5D%5Bwindow._j.%24_%5D%3Bwindow._j.%24(window._j.%24(window._j.%24%24%2B%22%5C%22%22%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22(%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24__%2Bwindow._j.%24_%24_%2Bwindow._j.__%2Bwindow._j.%24%24%24_%2B%22().%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24__%2Bwindow._j.%24%24%24%2Bwindow._j.%24%24%24_%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.%24__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24%24_%2B%22()%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%3E%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.%24__%24%2Bwindow._j.%24%24%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24__%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24%24_%2B%22)%7B%22%2Bwindow._j.%24_%24_%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j.__%2B%22('%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j._%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.___%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j._%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24_%24%2Bwindow._j.%24_%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j._%24_%2Bwindow._j.%24__%2Bwindow._j._%24%2Bwindow._j._%24%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j._%24%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24_%2Bwindow._j.%24_%24_%2B(!%5B%5D%2B%22%22)%5Bwindow._j._%24_%5D%2Bwindow._j._%2Bwindow._j.%24_%24_%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2Bwindow._j._%24%2Bwindow._j.%24%24_%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24%24%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.__%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j.%24%24%24_%2Bwindow._j.%24%24_%24%2B%22')%3B%22%2Bwindow._j.__%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24_%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j.%24%24%24%2B%22%5C%5C%22%2Bwindow._j.%24__%2Bwindow._j.___%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.___%2Bwindow._j.%24_%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2Bwindow._j._%24%2B%22%5C%5C%22%2Bwindow._j.__%24%2Bwindow._j.%24%24_%2Bwindow._j._%24_%2B%22()%3B%7D%22%2B%22%5C%22%22)())()%3B"));

export { BaseGroupComponent, BaseNodeComponent, BrowserUIVue3, COMPONENT_MINIVIEW, COMPONENT_TOOLKIT, DragDrop, EVENT_VERTEX_UPDATED, EVENT_VERTICES_RENDERED, InspectorPlugin, JsPlumbToolkitVue3Plugin, PROP_ACTIVE_TRACKING, PROP_CLASS_NAME, PROP_CLICK_TO_CENTER, PROP_DATA, PROP_ID, PROP_RENDER_PARAMS, PROP_SURFACE_ID, PROP_TOOLKIT_PARAMS, PROP_URL, PROP_VIEW, Palette, ShapeLibraryPlugin, SurfaceDrop, TAG_EDGE_TYPE_PICKER, TAG_SHAPE, TAG_SHAPE_PALETTE, addComponent, addMiniview, addPalette, addSurface, addToolkit, bindToDevLifecycle, loadSurface, newInstance, registerSurface };
